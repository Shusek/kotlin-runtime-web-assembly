package uk.shusek.krwa.component

import java.io.IOException
import java.io.UncheckedIOException
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.StringJoiner
import okio.FileSystem
import okio.Path
import okio.Path.Companion.toPath
import uk.shusek.krwa.component.CanonicalAbi.CoreValType
import uk.shusek.krwa.component.WitPackage.Declaration
import uk.shusek.krwa.component.WitPackage.Field
import uk.shusek.krwa.component.WitPackage.Function
import uk.shusek.krwa.component.WitPackage.InterfaceDeclaration
import uk.shusek.krwa.component.WitPackage.TypeDeclaration
import uk.shusek.krwa.component.WitPackage.TypeRef
import uk.shusek.krwa.component.WitPackage.UseDeclaration
import uk.shusek.krwa.component.WitPackage.UseItem
import uk.shusek.krwa.component.WitPackage.WorldDeclaration
import uk.shusek.krwa.component.WitPackage.WorldItem
import uk.shusek.krwa.wasm.types.FunctionType
import uk.shusek.krwa.wasm.types.ValType

class KotlinWitBindings private constructor(builder: Builder) {
    data class GeneratedFile(val relativePath: Path, val content: String)

    private val witPackage: WitPackage = builder.witPackage
    private val witSource: String? = builder.witSource
    private val packageName: String? = requireValidPackageName(builder.packageName)
    private val runtimePackageName: String? = builder.runtimePackageName
    private val includeRuntimeTypes: Boolean =
        builder.includeRuntimeTypes || builder.includeGuestExportAdapters
    private val includePluginHelpers: Boolean =
        builder.includePluginHelpers && !builder.includeRuntimeTypes
    private val includeGuestExportAdapters: Boolean = builder.includeGuestExportAdapters
    private val fileSystem: FileSystem = FileSystem.SYSTEM
    private val interfaceTypeNames: Map<InterfaceDeclaration, String> =
        interfaceTypeNames(builder.witPackage.interfaces())
    private val worldTypeNames: Map<WorldDeclaration, String> =
        worldTypeNames(builder.witPackage.worlds())
    private val canonicalAbi: CanonicalAbi = CanonicalAbi.of(builder.witPackage)
    private val guestExportStoreHelpers: Map<TypeDeclaration, GuestExportStoreHelper> =
        if (includeGuestExportAdapters) guestExportStoreHelpers() else emptyMap()

    fun generate(): String {
        val out = newKotlinFile(includeGuestExportImports = includeGuestExportAdapters)
        if (includeRuntimeTypes) {
            appendRuntimeTypes(out)
        } else {
            appendRuntimeImports(out)
        }
        for (declaration in witPackage.declarations()) {
            appendDeclaration(out, declaration, "")
        }
        if (includeGuestExportAdapters) {
            appendGuestExportAdapters(out)
        }
        return out.toString()
    }

    fun generateFiles(): List<GeneratedFile> {
        val files = ArrayList<GeneratedFile>()
        val usedNames = LinkedHashMap<String, Int>()
        if (includeRuntimeTypes) {
            val out = newKotlinFile()
            appendRuntimeTypes(out)
            files.add(generatedFile(uniqueFileName("RuntimeTypes", usedNames), out.toString()))
        }
        val aliases = StringBuilder()
        for (declaration in witPackage.declarations()) {
            if (declaration is UseDeclaration) {
                appendDeclaration(aliases, declaration, "")
                continue
            }
            val out = newKotlinFile()
            if (!includeRuntimeTypes) {
                appendRuntimeImports(out)
            }
            appendDeclaration(out, declaration, "")
            files.add(generatedFile(uniqueFileName(fileBaseName(declaration), usedNames), out.toString()))
        }
        if (aliases.isNotEmpty()) {
            val out = newKotlinFile()
            if (!includeRuntimeTypes) {
                appendRuntimeImports(out)
            }
            out.append(aliases)
            files.add(generatedFile(uniqueFileName("Aliases", usedNames), out.toString()))
        }
        if (includeGuestExportAdapters && guestExportBindings().isNotEmpty()) {
            val out = newKotlinFile(includeGuestExportImports = true)
            appendGuestExportAdapters(out)
            files.add(generatedFile(uniqueFileName("KrwaGuestExports", usedNames), out.toString()))
        }
        return files
    }

    fun writeTo(outputFile: Path): Path {
        try {
            val parent = outputFile.normalized().parent
            if (parent != null) {
                fileSystem.createDirectories(parent)
            }
            fileSystem.write(outputFile) { writeString(generate(), StandardCharsets.UTF_8) }
            return outputFile
        } catch (e: IOException) {
            throw UncheckedIOException(e)
        }
    }

    fun writeToDirectory(outputDirectory: Path): List<Path> {
        try {
            val normalizedOutput = outputDirectory.normalized()
            val packageDirectory = packageDirectory(normalizedOutput)
            if (packageDirectory != normalizedOutput) {
                fileSystem.deleteRecursively(packageDirectory, mustExist = false)
            }
            fileSystem.createDirectories(normalizedOutput)
            val written = ArrayList<Path>()
            for (file in generateFiles()) {
                val outputFile = normalizedOutput.resolve(file.relativePath.toString(), normalize = true)
                val parent = outputFile.parent
                if (parent != null) {
                    fileSystem.createDirectories(parent)
                }
                fileSystem.write(outputFile) { writeString(file.content, StandardCharsets.UTF_8) }
                written.add(outputFile)
            }
            return written
        } catch (e: IOException) {
            throw UncheckedIOException(e)
        }
    }

    private fun newKotlinFile(includeGuestExportImports: Boolean = false): StringBuilder {
        val out = StringBuilder()
        appendFileOptIn(out, includeGuestExportImports)
        if (packageName != null && packageName.isNotBlank()) {
            out.append("package ").append(packageName).append("\n\n")
        }
        if (includeGuestExportImports) {
            appendGuestExportImports(out)
        }
        appendGeneratedComment(out)
        return out
    }

    private fun appendFileOptIn(out: StringBuilder, includeGuestExportImports: Boolean) {
        out.append("@file:OptIn(kotlin.ExperimentalUnsignedTypes::class")
        if (includeGuestExportImports) {
            out.append(", kotlin.wasm.ExperimentalWasmInterop::class")
            out.append(", kotlin.wasm.unsafe.ComponentModelInternalApi::class")
            out.append(", kotlin.wasm.unsafe.UnsafeWasmMemoryApi::class")
        }
        out.append(")\n\n")
    }

    private fun appendGeneratedComment(out: StringBuilder) {
        out.append("// Generated by Kotlin Runtime Web Assembly Component Model. Do not edit.\n\n")
    }

    private fun generatedFile(fileName: String, content: String): GeneratedFile =
        GeneratedFile(packageRelativePath(fileName), content)

    private fun packageRelativePath(fileName: String): Path {
        val packagePath = packageName?.takeIf { it.isNotBlank() }?.replace('.', '/')
        return if (packagePath == null) fileName.toPath() else "$packagePath/$fileName".toPath()
    }

    private fun packageDirectory(outputDirectory: Path): Path {
        val packagePath = packageName?.takeIf { it.isNotBlank() }?.replace('.', '/')
        val directory =
            if (packagePath == null) {
                outputDirectory
            } else {
                outputDirectory.resolve(packagePath, normalize = true)
            }
        check(
            directory == outputDirectory ||
                directory.relativeTo(outputDirectory).segments.none { segment -> segment == ".." }
        ) {
            "generated package path must remain within outputDirectory"
        }
        return directory
    }

    private fun fileBaseName(declaration: Declaration): String =
        when (declaration) {
            is InterfaceDeclaration -> interfaceTypeName(declaration)
            is WorldDeclaration -> worldTypeName(declaration)
            is TypeDeclaration -> typeName(declaration.name())
            is UseDeclaration -> "Aliases"
            else -> "Declarations"
        }

    private fun uniqueFileName(baseName: String, usedNames: MutableMap<String, Int>): String {
        val firstCount = usedNames[baseName]
        if (firstCount == null) {
            usedNames[baseName] = 1
            return "$baseName.kt"
        }
        var count = firstCount + 1
        while (true) {
            val candidate = "${baseName}$count"
            if (!usedNames.containsKey(candidate)) {
                usedNames[baseName] = count
                usedNames[candidate] = 1
                return "$candidate.kt"
            }
            count++
        }
    }

    private fun appendRuntimeTypes(out: StringBuilder) {
        out.append("public sealed interface WitResult<out O, out E> {\n")
        out.append("  public data class Ok<out O>(public val value: O) : WitResult<O, Nothing>\n")
        out.append("  public data class Err<out E>(public val value: E) : WitResult<Nothing, E>\n")
        out.append("}\n\n")
        out.append("public data class WitResource<T>(public val handle: UInt)\n\n")
        appendInlineTupleTypes(out)
        out.append("public interface WitFuture<out T> {\n")
        out.append("  public val handle: Long\n")
        out.append("  public fun handle(): Long = handle\n")
        out.append("  public companion object {\n")
        out.append("    public fun <T> of(handle: Long): WitFuture<T> = Handle(handle)\n")
        out.append("  }\n")
        out.append("  public data class Handle<out T>(override val handle: Long) : WitFuture<T>\n")
        out.append("}\n\n")
        out.append("public interface WitStream<out T> {\n")
        out.append("  public val handle: Long\n")
        out.append("  public fun handle(): Long = handle\n")
        out.append("  public companion object {\n")
        out.append("    public fun <T> of(handle: Long): WitStream<T> = Handle(handle)\n")
        out.append("  }\n")
        out.append("  public data class Handle<out T>(override val handle: Long) : WitStream<T>\n")
        out.append("}\n\n")
    }

    private fun appendInlineTupleTypes(out: StringBuilder) {
        out.append("public data class WitTuple1<out A>(public val first: A)\n\n")
        out.append(
            "public data class WitTuple4<out A, out B, out C, out D>(public val first: A," +
                " public val second: B, public val third: C, public val fourth: D)\n\n"
        )
        out.append(
            "public data class WitTuple5<out A, out B, out C, out D, out E>(public val first:" +
                " A, public val second: B, public val third: C, public val fourth: D," +
                " public val fifth: E)\n\n"
        )
        out.append(
            "public data class WitTuple6<out A, out B, out C, out D, out E, out F>(public val" +
                " first: A, public val second: B, public val third: C, public val" +
                " fourth: D, public val fifth: E, public val sixth: F)\n\n"
        )
        out.append(
            "public data class WitTuple7<out A, out B, out C, out D, out E, out F, out G>(" +
                "public val first: A, public val second: B, public val third: C, public" +
                " val fourth: D, public val fifth: E, public val sixth: F, public val" +
                " seventh: G)\n\n"
        )
        out.append(
            "public data class WitTuple8<out A, out B, out C, out D, out E, out F, out G, out" +
                " H>(public val first: A, public val second: B, public val third: C," +
                " public val fourth: D, public val fifth: E, public val sixth: F, public" +
                " val seventh: G, public val eighth: H)\n\n"
        )
    }

    private fun appendRuntimeImports(out: StringBuilder) {
        if (
            runtimePackageName == null ||
                runtimePackageName.isBlank() ||
                runtimePackageName == packageName
        ) {
            return
        }
        out.append("import ").append(runtimePackageName).append(".WitFuture\n")
        out.append("import ").append(runtimePackageName).append(".WitResource\n")
        out.append("import ").append(runtimePackageName).append(".WitResult\n")
        out.append("import ").append(runtimePackageName).append(".WitStream\n\n")
        if (includePluginHelpers) {
            out.append("import ").append(runtimePackageName).append(".WasiComponentInvoker\n")
            out.append("import ").append(runtimePackageName).append(".WitValue\n\n")
        }
        out.append("import ").append(runtimePackageName).append(".WitTuple1\n")
        out.append("import ").append(runtimePackageName).append(".WitTuple4\n")
        out.append("import ").append(runtimePackageName).append(".WitTuple5\n")
        out.append("import ").append(runtimePackageName).append(".WitTuple6\n")
        out.append("import ").append(runtimePackageName).append(".WitTuple7\n")
        out.append("import ").append(runtimePackageName).append(".WitTuple8\n\n")
    }

    private fun appendGuestExportImports(out: StringBuilder) {
        if (!includeGuestExportAdapters) {
            return
        }
        out.append("import kotlin.coroutines.Continuation\n")
        out.append("import kotlin.coroutines.EmptyCoroutineContext\n")
        out.append("import kotlin.coroutines.startCoroutine\n")
        out.append("import kotlin.wasm.WasmExport\n")
        out.append("import kotlin.wasm.WasmImport\n")
        out.append("import kotlin.wasm.unsafe.Pointer\n")
        out.append("import kotlin.wasm.unsafe.componentModelRealloc\n")
        out.append("import kotlin.wasm.unsafe.freeAllComponentModelReallocAllocatedMemory\n\n")
    }

    private fun appendDeclaration(out: StringBuilder, declaration: Declaration, indent: String) {
        when (declaration) {
            is InterfaceDeclaration -> appendInterface(out, declaration, indent)
            is WorldDeclaration -> appendWorld(out, declaration, indent)
            is TypeDeclaration -> appendTypeDeclaration(out, declaration, indent)
            is UseDeclaration -> appendUseAliases(out, declaration, indent, null)
        }
    }

    private fun appendInterface(
        out: StringBuilder,
        declaration: InterfaceDeclaration,
        indent: String,
    ) {
        out.append(indent)
            .append("public interface ")
            .append(interfaceTypeName(declaration))
            .append(" {\n")
        for (member in declaration.members()) {
            when (member) {
                is Function -> appendFunction(out, member, "$indent  ", declaration)
                is TypeDeclaration -> {
                    appendTypeDeclaration(out, member, "$indent  ")
                    if (member.kind() == TypeDeclaration.Kind.RESOURCE) {
                        appendResourceBridgeFunctions(out, member, "$indent  ")
                    }
                }
                is UseDeclaration ->
                    appendUseAliases(out, member, "$indent  ", declaration.packageName())
            }
        }
        out.append(indent).append("}\n\n")
    }

    private fun appendUseAliases(
        out: StringBuilder,
        declaration: UseDeclaration,
        indent: String,
        packageContext: String?,
    ) {
        for (item in declaration.items()) {
            val localName = typeName(item.localName())
            val targetName = useTargetType(declaration, item, localName, packageContext)
            out.append(indent)
                .append("public typealias ")
                .append(localName)
                .append(" = ")
                .append(targetName)
                .append("\n")
            if (targetName.startsWith("WitResource<")) {
                out.append(indent).append("public object ").append(localName).append("Tag\n")
            }
        }
        out.append("\n")
    }

    private fun useTargetType(
        declaration: UseDeclaration,
        item: UseItem,
        localName: String,
        packageContext: String?,
    ): String {
        val targetInterface = findInterface(declaration.path(), packageContext)
        if (targetInterface != null) {
            return interfaceTypeName(targetInterface) + "." + typeName(item.name())
        }
        if (hasTypeDeclaration(item.name()) && localName != typeName(item.name())) {
            return typeName(item.name())
        }
        return "WitResource<${localName}Tag>"
    }

    private fun appendWorld(out: StringBuilder, declaration: WorldDeclaration, indent: String) {
        out.append(indent)
            .append("public object ")
            .append(worldTypeName(declaration))
            .append(" {\n")
        for (worldDeclaration in declaration.declarations()) {
            appendDeclaration(out, worldDeclaration, "$indent  ")
        }
        appendWorldSide(out, "Host", declaration.imports(), "$indent  ")
        appendWorldSide(out, "Guest", declaration.exports(), "$indent  ")
        if (includePluginHelpers) {
            appendWorldPluginHelpers(out, declaration, "$indent  ")
        }
        out.append(indent).append("}\n\n")
    }

    private fun appendWorldPluginHelpers(
        out: StringBuilder,
        declaration: WorldDeclaration,
        indent: String,
    ) {
        val wasmPlugin = runtimeType("WasmPlugin")
        val packageName = declaration.packageName() ?: witPackage.packageName().orEmpty()
        val packageVersion = packageVersion(packageName)
        val packageMajor = packageMajorVersion(packageVersion)
        out.append(indent)
            .append("public const val WIT_PACKAGE: String = ")
            .append(kotlinString(packageName))
            .append("\n")
        out.append(indent)
            .append("public const val WIT_PACKAGE_VERSION: String = ")
            .append(kotlinString(packageVersion))
            .append("\n")
        out.append(indent)
            .append("public const val WIT_PACKAGE_MAJOR_VERSION: Int = ")
            .append(packageMajor)
            .append("\n")
        out.append(indent)
            .append("public const val WIT_WORLD: String = ")
            .append(kotlinString(declaration.name()))
            .append("\n")
        out.append(indent)
            .append("public const val WIT_QUALIFIED_WORLD: String = ")
            .append(kotlinString(declaration.qualifiedName()))
            .append("\n")
        if (witSource != null) {
            out.append(indent)
                .append("public const val WIT_SOURCE: String = ")
                .append(kotlinString(witSource))
                .append("\n")
        }
        out.append("\n")
        out.append(indent)
            .append("public fun installHost(builder: ")
            .append(wasmPlugin)
            .append(".Builder, host: Host): ")
            .append(wasmPlugin)
            .append(".Builder =\n")
        out.append(indent).append("  builder.withWorld(WIT_WORLD).withHost(host)\n\n")
        out.append(indent)
            .append("public fun build(builder: ")
            .append(wasmPlugin)
            .append(".Builder, host: Host): ")
            .append(wasmPlugin)
            .append(" =\n")
        out.append(indent).append("  installHost(builder, host).build()\n\n")
        out.append(indent)
            .append("public fun guest(plugin: ")
            .append(wasmPlugin)
            .append("): Guest =\n")
        out.append(indent)
            .append("  plugin.exports(uk.shusek.krwa.component.componentModelJvmClass<Guest>())\n\n")
        appendWorldGuestInvoker(out, declaration, indent)
        appendPluginHelperRuntime(out, indent)
    }

    private fun appendWorldGuestInvoker(
        out: StringBuilder,
        declaration: WorldDeclaration,
        indent: String,
    ) {
        out.append(indent)
            .append("public fun guest(invoker: ")
            .append(runtimeType("WasiComponentInvoker"))
            .append("): Guest =\n")
        out.append(indent).append("  object : Guest {\n")
        for (item in declaration.exports()) {
            if (item.isFunction) {
                appendInvokerFunction(out, item.function()!!, null, item.name(), "$indent    ")
                continue
            }
            val exportedInterface = findInterfaceForWorldItem(item)
            val propertyName = memberName(worldItemMemberName(item, declaration.exports()))
            out.append(indent)
                .append("    override val ")
                .append(propertyName)
                .append(": ")
                .append(worldItemType(item.type()))
                .append(" = object : ")
                .append(worldItemType(item.type()))
                .append(" {\n")
            val interfaceName = interfaceName(item)
            for (member in exportedInterface.members()) {
                if (member is Function) {
                    appendInvokerFunction(
                        out,
                        member,
                        exportedInterface,
                        "$interfaceName.${member.name()}",
                        "$indent      ",
                    )
                }
            }
            out.append(indent).append("    }\n")
        }
        out.append(indent).append("  }\n")
    }

    private fun appendInvokerFunction(
        out: StringBuilder,
        function: Function,
        owner: InterfaceDeclaration?,
        exportName: String,
        indent: String,
    ) {
        out.append(indent).append("override ")
        if (function.isAsync) {
            out.append("suspend ")
        }
        out.append("fun ").append(memberName(function.name())).append("(")
        for (index in function.parameters().indices) {
            val param = function.parameters()[index]
            if (index > 0) {
                out.append(", ")
            }
            out.append(memberName(param.name())).append(": ").append(adapterKotlinType(param.type()))
        }
        out.append(")")
        if (function.results().isNotEmpty()) {
            out.append(": ").append(adapterReturnType(function.results()))
        }
        out.append(" {\n")
        out.append(indent)
            .append("  val __krwaResult = invoker.call(")
            .append(kotlinString(exportName))
        for (param in function.parameters()) {
            val name = memberName(param.name())
            out.append(", ").append(toAbiExpression(name, param.type(), owner))
        }
        out.append(")\n")
        if (function.results().isEmpty()) {
            out.append(indent).append("  return\n")
        } else {
            out.append(indent)
                .append("  return ")
                .append(fromAbiReturnExpression("__krwaResult", function.results(), owner))
                .append("\n")
        }
        out.append(indent).append("}\n")
    }

    private fun appendPluginHelperRuntime(out: StringBuilder, indent: String) {
        out.append("\n")
        out.append(indent).append("private fun __krwaRequireMap(value: Any?, context: String): Map<*, *> =\n")
        out.append(indent).append("  value as? Map<*, *> ?: error(\"expected WIT record for ${'$'}context, got ${'$'}value\")\n\n")
        out.append(indent).append("private fun __krwaRequireList(value: Any?, context: String): List<*> =\n")
        out.append(indent).append("  value as? List<*> ?: error(\"expected WIT list for ${'$'}context, got ${'$'}value\")\n\n")
        out.append(indent).append("private fun __krwaRequireByteArray(value: Any?, context: String): ByteArray =\n")
        out.append(indent).append("  value as? ByteArray ?: error(\"expected WIT byte list for ${'$'}context, got ${'$'}value\")\n\n")
        out.append(indent).append("private fun __krwaField(value: Any?, name: String, context: String): Any? =\n")
        out.append(indent).append("  __krwaRequireMap(value, context)[name]\n\n")
        out.append(indent).append("private fun __krwaFlag(value: Any?, name: String, context: String): Boolean =\n")
        out.append(indent).append("  __krwaRequireMap(value, context)[name] == true\n\n")
        out.append(indent).append("private fun __krwaVariant(value: Any?, context: String): WitValue.Variant =\n")
        out.append(indent).append("  value as? WitValue.Variant ?: error(\"expected WIT variant for ${'$'}context, got ${'$'}value\")\n\n")
        out.append(indent).append("private fun __krwaVariantValue(value: Any?, context: String): Any? =\n")
        out.append(indent).append("  __krwaVariant(value, context).value()\n\n")
        out.append(indent).append("private fun __krwaAsLong(value: Any?, context: String): Long =\n")
        out.append(indent).append("  when (value) {\n")
        out.append(indent).append("    is Byte -> value.toLong()\n")
        out.append(indent).append("    is Short -> value.toLong()\n")
        out.append(indent).append("    is Int -> value.toLong()\n")
        out.append(indent).append("    is Long -> value\n")
        out.append(indent).append("    is UByte -> value.toLong()\n")
        out.append(indent).append("    is UShort -> value.toLong()\n")
        out.append(indent).append("    is UInt -> value.toLong()\n")
        out.append(indent).append("    is ULong -> value.toLong()\n")
        out.append(indent).append("    else -> error(\"expected numeric WIT value for ${'$'}context, got ${'$'}value\")\n")
        out.append(indent).append("  }\n\n")
        out.append(indent).append("private fun __krwaAsBoolean(value: Any?, context: String): Boolean =\n")
        out.append(indent).append("  value as? Boolean ?: (__krwaAsLong(value, context) != 0L)\n\n")
        out.append(indent).append("private fun __krwaAsString(value: Any?, context: String): String =\n")
        out.append(indent).append("  value as? String ?: error(\"expected WIT string for ${'$'}context, got ${'$'}value\")\n")
    }

    private fun fromAbiReturnExpression(
        value: String,
        results: List<Field>,
        owner: InterfaceDeclaration?,
    ): String {
        if (results.size == 1) {
            return fromAbiExpression(value, results[0].type(), owner, "result")
        }
        val list = "__krwaRequireList($value, \"result\")"
        val expressions =
            results.mapIndexed { index, field ->
                fromAbiExpression("$list[$index]", field.type(), owner, "result.$index")
            }
        return tupleConstructionExpression(expressions)
    }

    private fun fromAbiExpression(
        value: String,
        type: TypeRef,
        owner: InterfaceDeclaration?,
        context: String,
    ): String {
        val resolved = resolveAlias(type)
        if (resolved.kind() == TypeRef.TypeKind.PRIMITIVE) {
            return fromAbiPrimitiveExpression(value, resolved.name()!!, context)
        }
        if (resolved.kind() == TypeRef.TypeKind.NAMED) {
            val declaration = findTypeDeclaration(resolved.name()!!)
            if (declaration != null) {
                return fromAbiDeclarationExpression(value, declaration, owner, context)
            }
        }
        val args = resolved.arguments()
        return when (resolved.kind()) {
            TypeRef.TypeKind.LIST ->
                fromAbiListExpression(
                    value,
                    if (args.isEmpty()) TypeRef.primitive("unit") else args[0],
                    owner,
                    context,
                )
            TypeRef.TypeKind.OPTION ->
                "(if (__krwaVariant($value, ${kotlinString(context)}).label() == \"none\") null else " +
                    fromAbiExpression(
                        "__krwaVariantValue($value, ${kotlinString(context)})",
                        args[0],
                        owner,
                        "$context.some",
                    ) +
                    ")"
            TypeRef.TypeKind.RESULT ->
                fromAbiResultExpression(value, args, owner, context)
            TypeRef.TypeKind.TUPLE ->
                fromAbiTupleExpression(value, args, owner, context)
            TypeRef.TypeKind.FUTURE ->
                "WitFuture.of<${optionalArgument(args, false, owner)}>(" +
                    "__krwaAsLong($value, ${kotlinString(context)}))"
            TypeRef.TypeKind.STREAM ->
                "WitStream.of<${optionalArgument(args, false, owner)}>(" +
                    "__krwaAsLong($value, ${kotlinString(context)}))"
            TypeRef.TypeKind.BORROW,
            TypeRef.TypeKind.OWN ->
                "WitResource(__krwaAsLong($value, ${kotlinString(context)}).toUInt())"
            else -> value
        }
    }

    private fun fromAbiPrimitiveExpression(value: String, name: String, context: String): String =
        when (name) {
            "unit" -> "Unit"
            "bool" -> "__krwaAsBoolean($value, ${kotlinString(context)})"
            "s8" -> "__krwaAsLong($value, ${kotlinString(context)}).toByte()"
            "s16" -> "__krwaAsLong($value, ${kotlinString(context)}).toShort()"
            "s32",
            "char" -> "__krwaAsLong($value, ${kotlinString(context)}).toInt()"
            "s64" -> "__krwaAsLong($value, ${kotlinString(context)})"
            "u8" -> "__krwaAsLong($value, ${kotlinString(context)}).toUByte()"
            "u16" -> "__krwaAsLong($value, ${kotlinString(context)}).toUShort()"
            "u32" -> "__krwaAsLong($value, ${kotlinString(context)}).toUInt()"
            "u64" -> "__krwaAsLong($value, ${kotlinString(context)}).toULong()"
            "f32" -> "($value as Number).toFloat()"
            "f64" -> "($value as Number).toDouble()"
            "string" -> "__krwaAsString($value, ${kotlinString(context)})"
            else -> "$value as ${typeName(name)}"
        }

    private fun fromAbiDeclarationExpression(
        value: String,
        declaration: TypeDeclaration,
        owner: InterfaceDeclaration?,
        context: String,
    ): String =
        when (declaration.kind()) {
            TypeDeclaration.Kind.RECORD -> fromAbiRecordExpression(value, declaration, owner, context)
            TypeDeclaration.Kind.FLAGS -> fromAbiFlagsExpression(value, declaration, context)
            TypeDeclaration.Kind.ENUM -> fromAbiEnumExpression(value, declaration, context)
            TypeDeclaration.Kind.VARIANT -> fromAbiVariantExpression(value, declaration, owner, context)
            TypeDeclaration.Kind.RESOURCE ->
                "WitResource(__krwaAsLong($value, ${kotlinString(context)}).toUInt())"
            TypeDeclaration.Kind.ALIAS -> fromAbiExpression(value, declaration.target()!!, owner, context)
        }

    private fun fromAbiRecordExpression(
        value: String,
        declaration: TypeDeclaration,
        owner: InterfaceDeclaration?,
        context: String,
    ): String =
        adapterTypeName(declaration) +
            "(" +
            declaration.fields().joinToString(", ") { field ->
                memberName(field.name()) +
                    " = " +
                    fromAbiExpression(
                        "__krwaField($value, ${kotlinString(field.name())}, ${kotlinString(context)})",
                        field.type(),
                        owner,
                        "$context.${field.name()}",
                    )
            } +
            ")"

    private fun fromAbiFlagsExpression(
        value: String,
        declaration: TypeDeclaration,
        context: String,
    ): String =
        adapterTypeName(declaration) +
            "(" +
            declaration.cases().joinToString(", ") { flag ->
                memberName(flag.name()) +
                    " = __krwaFlag($value, ${kotlinString(flag.name())}, ${kotlinString(context)})"
            } +
            ")"

    private fun fromAbiEnumExpression(value: String, declaration: TypeDeclaration, context: String): String =
        "when (__krwaVariant($value, ${kotlinString(context)}).label()) {" +
            declaration.cases().joinToString("; ") { witCase ->
                "${kotlinString(witCase.name())} -> ${adapterTypeName(declaration)}.${enumName(witCase.name())}"
            } +
            "; else -> error(\"unknown WIT enum case\") }"

    private fun fromAbiVariantExpression(
        value: String,
        declaration: TypeDeclaration,
        owner: InterfaceDeclaration?,
        context: String,
    ): String {
        val type = adapterTypeName(declaration)
        return "when (__krwaVariant($value, ${kotlinString(context)}).label()) {" +
            declaration.cases().joinToString("; ") { witCase ->
                val target = "$type.${typeName(witCase.name())}"
                if (witCase.type() == null) {
                    "${kotlinString(witCase.name())} -> $target"
                } else {
                    "${kotlinString(witCase.name())} -> $target(" +
                        fromAbiExpression(
                            "__krwaVariantValue($value, ${kotlinString(context)})",
                            witCase.type()!!,
                            owner,
                            "$context.${witCase.name()}",
                        ) +
                        ")"
                }
            } +
            "; else -> error(\"unknown WIT variant case\") }"
    }

    private fun fromAbiResultExpression(
        value: String,
        args: List<TypeRef>,
        owner: InterfaceDeclaration?,
        context: String,
    ): String {
        val okType = if (args.isEmpty()) TypeRef.primitive("unit") else args[0]
        val errType = if (args.size <= 1) TypeRef.primitive("unit") else args[1]
        return "when (__krwaVariant($value, ${kotlinString(context)}).label()) {" +
            "\"ok\" -> WitResult.Ok(" +
            fromAbiExpression(
                "__krwaVariantValue($value, ${kotlinString(context)})",
                okType,
                owner,
                "$context.ok",
            ) +
            "); \"err\" -> WitResult.Err(" +
            fromAbiExpression(
                "__krwaVariantValue($value, ${kotlinString(context)})",
                errType,
                owner,
                "$context.err",
            ) +
            "); else -> error(\"unknown WIT result case\") }"
    }

    private fun fromAbiTupleExpression(
        value: String,
        args: List<TypeRef>,
        owner: InterfaceDeclaration?,
        context: String,
    ): String {
        val list = "__krwaRequireList($value, ${kotlinString(context)})"
        return tupleConstructionExpression(
            args.mapIndexed { index, type ->
                fromAbiExpression("$list[$index]", type, owner, "$context.$index")
            }
        )
    }

    private fun fromAbiListExpression(
        value: String,
        elementType: TypeRef,
        owner: InterfaceDeclaration?,
        context: String,
    ): String {
        if (elementType.kind() == TypeRef.TypeKind.PRIMITIVE) {
            return when (elementType.name()) {
                "s8" -> "__krwaRequireByteArray($value, ${kotlinString(context)})"
                "u8" -> "__krwaRequireByteArray($value, ${kotlinString(context)}).asUByteArray()"
                "s16" -> "__krwaRequireList($value, ${kotlinString(context)}).map { __krwaAsLong(it, ${kotlinString(context)}).toShort() }.toShortArray()"
                "s32" -> "__krwaRequireList($value, ${kotlinString(context)}).map { __krwaAsLong(it, ${kotlinString(context)}).toInt() }.toIntArray()"
                "s64" -> "__krwaRequireList($value, ${kotlinString(context)}).map { __krwaAsLong(it, ${kotlinString(context)}) }.toLongArray()"
                "u16" -> "__krwaRequireList($value, ${kotlinString(context)}).map { __krwaAsLong(it, ${kotlinString(context)}).toUShort() }.toUShortArray()"
                "u32" -> "__krwaRequireList($value, ${kotlinString(context)}).map { __krwaAsLong(it, ${kotlinString(context)}).toUInt() }.toUIntArray()"
                "u64" -> "__krwaRequireList($value, ${kotlinString(context)}).map { __krwaAsLong(it, ${kotlinString(context)}).toULong() }.toULongArray()"
                "f32" -> "__krwaRequireList($value, ${kotlinString(context)}).map { (it as Number).toFloat() }.toFloatArray()"
                "f64" -> "__krwaRequireList($value, ${kotlinString(context)}).map { (it as Number).toDouble() }.toDoubleArray()"
                else -> null
            } ?: "__krwaRequireList($value, ${kotlinString(context)}).map { " +
                fromAbiExpression("it", elementType, owner, "$context.item") +
                " }"
        }
        return "__krwaRequireList($value, ${kotlinString(context)}).map { " +
            fromAbiExpression("it", elementType, owner, "$context.item") +
            " }"
    }

    private fun toAbiExpression(value: String, type: TypeRef, owner: InterfaceDeclaration?): String {
        val resolved = resolveAlias(type)
        if (resolved.kind() == TypeRef.TypeKind.PRIMITIVE) {
            return toAbiPrimitiveExpression(value, resolved.name()!!)
        }
        if (resolved.kind() == TypeRef.TypeKind.NAMED) {
            val declaration = findTypeDeclaration(resolved.name()!!)
            if (declaration != null) {
                return toAbiDeclarationExpression(value, declaration, owner)
            }
        }
        val args = resolved.arguments()
        return when (resolved.kind()) {
            TypeRef.TypeKind.LIST ->
                toAbiListExpression(value, if (args.isEmpty()) TypeRef.primitive("unit") else args[0], owner)
            TypeRef.TypeKind.OPTION ->
                "(if ($value == null) WitValue.none() else WitValue.some(" +
                    toAbiExpression(value, args[0], owner) +
                    "))"
            TypeRef.TypeKind.RESULT ->
                toAbiResultExpression(value, args, owner)
            TypeRef.TypeKind.TUPLE ->
                toAbiTupleExpression(value, args, owner)
            TypeRef.TypeKind.FUTURE,
            TypeRef.TypeKind.STREAM,
            TypeRef.TypeKind.BORROW,
            TypeRef.TypeKind.OWN -> "$value.handle()"
            else -> value
        }
    }

    private fun toAbiPrimitiveExpression(value: String, name: String): String =
        when (name) {
            "unit" -> "null"
            "u8",
            "u16",
            "u32",
            "u64" -> "$value.toLong()"
            else -> value
        }

    private fun toAbiDeclarationExpression(
        value: String,
        declaration: TypeDeclaration,
        owner: InterfaceDeclaration?,
    ): String =
        when (declaration.kind()) {
            TypeDeclaration.Kind.RECORD ->
                "WitValue.record(" +
                    declaration.fields().joinToString(", ") { field ->
                        kotlinString(field.name()) +
                            ", " +
                            toAbiExpression("$value.${memberName(field.name())}", field.type(), owner)
                    } +
                    ")"
            TypeDeclaration.Kind.FLAGS ->
                "WitValue.flags(*listOf(" +
                    declaration.cases().joinToString(", ") { flag ->
                        "if ($value.${memberName(flag.name())}) ${kotlinString(flag.name())} else null"
                    } +
                    ").filterNotNull().toTypedArray())"
            TypeDeclaration.Kind.ENUM ->
                "when ($value) {" +
                    declaration.cases().joinToString("; ") { witCase ->
                        "${adapterTypeName(declaration)}.${enumName(witCase.name())} -> " +
                            "WitValue.variant(${kotlinString(witCase.name())})"
                    } +
                    " }"
            TypeDeclaration.Kind.VARIANT -> toAbiVariantExpression(value, declaration, owner)
            TypeDeclaration.Kind.RESOURCE -> "$value.handle()"
            TypeDeclaration.Kind.ALIAS -> toAbiExpression(value, declaration.target()!!, owner)
        }

    private fun toAbiVariantExpression(
        value: String,
        declaration: TypeDeclaration,
        owner: InterfaceDeclaration?,
    ): String {
        val type = adapterTypeName(declaration)
        return "when ($value) {" +
            declaration.cases().joinToString("; ") { witCase ->
                val caseType = "$type.${typeName(witCase.name())}"
                if (witCase.type() == null) {
                    "$caseType -> WitValue.variant(${kotlinString(witCase.name())})"
                } else {
                    "is $caseType -> WitValue.variant(${kotlinString(witCase.name())}, " +
                        toAbiExpression("$value.value", witCase.type()!!, owner) +
                        ")"
                }
            } +
            " }"
    }

    private fun toAbiResultExpression(
        value: String,
        args: List<TypeRef>,
        owner: InterfaceDeclaration?,
    ): String {
        val okType = if (args.isEmpty()) TypeRef.primitive("unit") else args[0]
        val errType = if (args.size <= 1) TypeRef.primitive("unit") else args[1]
        return "when ($value) {" +
            "is WitResult.Ok -> WitValue.ok(" +
            toAbiExpression("$value.value", okType, owner) +
            "); is WitResult.Err -> WitValue.err(" +
            toAbiExpression("$value.value", errType, owner) +
            ") }"
    }

    private fun toAbiTupleExpression(value: String, args: List<TypeRef>, owner: InterfaceDeclaration?): String {
        val accessors = args.indices.map { index -> tupleAccessor(index) }
        return "listOf(" +
            args.mapIndexed { index, type ->
                toAbiExpression("$value.${accessors[index]}", type, owner)
            }.joinToString(", ") +
            ")"
    }

    private fun toAbiListExpression(value: String, elementType: TypeRef, owner: InterfaceDeclaration?): String {
        if (elementType.kind() == TypeRef.TypeKind.PRIMITIVE) {
            return when (elementType.name()) {
                "s8" -> value
                "u8" -> "$value.asByteArray()"
                else -> "$value.map { ${toAbiExpression("it", elementType, owner)} }"
            }
        }
        return "$value.map { ${toAbiExpression("it", elementType, owner)} }"
    }

    private fun tupleConstructionExpression(expressions: List<String>): String =
        when (expressions.size) {
            0 -> "Unit"
            1 -> "WitTuple1(${expressions[0]})"
            2 -> "Pair(${expressions[0]}, ${expressions[1]})"
            3 -> "Triple(${expressions[0]}, ${expressions[1]}, ${expressions[2]})"
            in 4..8 -> "WitTuple${expressions.size}(${expressions.joinToString(", ")})"
            else -> "listOf(${expressions.joinToString(", ")})"
        }

    private fun appendWorldSide(
        out: StringBuilder,
        name: String,
        items: List<WorldItem>,
        indent: String,
    ) {
        out.append(indent).append("public interface ").append(name).append(" {\n")
        for (item in items) {
            if (item.isFunction) {
                appendFunction(out, item.function()!!, "$indent  ")
            } else {
                out.append(indent)
                    .append("  public val ")
                    .append(memberName(worldItemMemberName(item, items)))
                    .append(": ")
                    .append(worldItemType(item.type()))
                    .append("\n")
            }
        }
        out.append(indent).append("}\n")
    }

    private fun worldItemMemberName(item: WorldItem, items: List<WorldItem>): String {
        val localName = WitNames.lastSegment(item.name())
        if (localName == item.name()) {
            return item.name()
        }
        for (other in items) {
            if (other === item) {
                continue
            }
            if (WitNames.lastSegment(other.name()) == localName) {
                return item.name()
            }
        }
        return localName
    }

    private fun appendTypeDeclaration(
        out: StringBuilder,
        declaration: TypeDeclaration,
        indent: String,
    ) {
        when (declaration.kind()) {
            TypeDeclaration.Kind.RECORD -> appendRecord(out, declaration, indent)
            TypeDeclaration.Kind.VARIANT -> appendVariant(out, declaration, indent)
            TypeDeclaration.Kind.ENUM -> appendEnum(out, declaration, indent)
            TypeDeclaration.Kind.FLAGS -> appendFlags(out, declaration, indent)
            TypeDeclaration.Kind.RESOURCE -> appendResource(out, declaration, indent)
            TypeDeclaration.Kind.ALIAS -> {
                out.append(indent)
                    .append("public typealias ")
                    .append(typeName(declaration.name()))
                    .append(" = ")
                    .append(kotlinType(declaration.target()))
                    .append("\n\n")
            }
        }
    }

    private fun appendResource(out: StringBuilder, declaration: TypeDeclaration, indent: String) {
        val typeName = typeName(declaration.name())
        out.append(indent)
            .append("public typealias ")
            .append(typeName)
            .append(" = WitResource<")
            .append(typeName)
            .append("Tag>\n")
        out.append(indent).append("public object ").append(typeName).append("Tag\n\n")
    }

    private fun appendRecord(out: StringBuilder, declaration: TypeDeclaration, indent: String) {
        out.append(indent)
            .append("public data class ")
            .append(typeName(declaration.name()))
            .append("(\n")
        appendConstructorFields(out, declaration.fields(), indent)
        out.append(indent).append(")\n\n")
    }

    private fun appendVariant(out: StringBuilder, declaration: TypeDeclaration, indent: String) {
        val typeName = typeName(declaration.name())
        out.append(indent).append("public sealed interface ").append(typeName).append(" {\n")
        for (witCase in declaration.cases()) {
            val caseName = typeName(witCase.name())
            if (witCase.type() == null) {
                out.append(indent)
                    .append("  public object ")
                    .append(caseName)
                    .append(" : ")
                    .append(typeName)
                    .append("\n")
            } else {
                out.append(indent)
                    .append("  public data class ")
                    .append(caseName)
                    .append("(public val value: ")
                    .append(kotlinType(witCase.type()))
                    .append(") : ")
                    .append(typeName)
                    .append("\n")
            }
        }
        out.append(indent).append("}\n\n")
    }

    private fun appendEnum(out: StringBuilder, declaration: TypeDeclaration, indent: String) {
        out.append(indent)
            .append("public enum class ")
            .append(typeName(declaration.name()))
            .append(" {\n")
        val names = StringJoiner(",\n")
        for (witCase in declaration.cases()) {
            names.add(indent + "  " + enumName(witCase.name()))
        }
        out.append(names).append("\n")
        out.append(indent).append("}\n\n")
    }

    private fun appendFlags(out: StringBuilder, declaration: TypeDeclaration, indent: String) {
        val fields = ArrayList<Field>()
        for (flag in declaration.cases()) {
            fields.add(Field(flag.name(), TypeRef.primitive("bool")))
        }
        out.append(indent)
            .append("public data class ")
            .append(typeName(declaration.name()))
            .append("(\n")
        appendConstructorFields(out, fields, indent)
        out.append(indent).append(")\n\n")
    }

    private fun appendConstructorFields(out: StringBuilder, fields: List<Field>, indent: String) {
        for (index in fields.indices) {
            val field = fields[index]
            out.append(indent)
                .append("  public val ")
                .append(memberName(field.name()))
                .append(": ")
                .append(kotlinType(field.type()))
            if (index + 1 < fields.size) {
                out.append(",")
            }
            out.append("\n")
        }
    }

    private fun appendFunction(
        out: StringBuilder,
        function: Function,
        indent: String,
        owner: InterfaceDeclaration? = null,
    ) {
        appendFunction(out, function, indent, owner, null)
    }

    private fun appendResourceBridgeFunctions(
        out: StringBuilder,
        declaration: TypeDeclaration,
        indent: String,
    ) {
        if (declaration.functions().isEmpty()) {
            return
        }
        val resourceType = typeName(declaration.name())
        for (function in declaration.functions()) {
            appendResourceBridgeFunction(out, declaration.name(), resourceType, function, indent)
        }
        out.append("\n")
    }

    private fun appendResourceBridgeFunction(
        out: StringBuilder,
        resourceName: String,
        resourceType: String,
        function: Function,
        indent: String,
    ) {
        out.append(indent).append("public ")
        if (function.isAsync) {
            out.append("suspend ")
        }
        out.append("fun ").append(memberName("$resourceName.${function.name()}")).append("(")
        var first = true
        if (!function.isConstructor && !function.isStatic) {
            out.append("self: ").append(resourceHandleType(resourceType))
            first = false
        }
        for (param in function.parameters()) {
            if (!first) {
                out.append(", ")
            }
            out.append(memberName(param.name())).append(": ").append(kotlinType(param.type()))
            first = false
        }
        out.append(")")
        val returnType = resourceBridgeReturnType(resourceType, function)
        if (returnType != null) {
            out.append(": ").append(returnType)
        }
        out.append("\n")
    }

    private fun resourceBridgeReturnType(resourceType: String, function: Function): String? {
        if (function.isConstructor) {
            return resourceHandleType(resourceType)
        }
        if (function.results().isEmpty()) {
            return null
        }
        if (function.results().size == 1) {
            return resourceAwareKotlinType(function.results()[0].type())
        }
        return returnType(function.results(), true)
    }

    private fun appendFunction(
        out: StringBuilder,
        function: Function,
        indent: String,
        owner: InterfaceDeclaration?,
        forcedReturnType: String?,
    ) {
        out.append(indent).append("public ")
        if (function.isAsync) {
            out.append("suspend ")
        }
        out.append("fun ").append(memberName(function.name())).append("(")
        for (index in function.parameters().indices) {
            val param = function.parameters()[index]
            if (index > 0) {
                out.append(", ")
            }
            out.append(memberName(param.name())).append(": ").append(kotlinType(param.type(), owner))
        }
        out.append(")")
        if (forcedReturnType != null) {
            out.append(": ").append(forcedReturnType)
        } else if (!function.results().isEmpty()) {
            out.append(": ").append(returnType(function.results(), owner))
        }
        out.append("\n")
    }

    private fun worldItemType(type: TypeRef?): String {
        if (
            type != null &&
                type.kind() == TypeRef.TypeKind.NAMED &&
                packageName != null &&
                packageName.isNotBlank()
        ) {
            val declaration = findInterface(type.name()!!)
            if (declaration != null) {
                return packageName + "." + interfaceTypeName(declaration)
            }
        }
        return kotlinType(type)
    }

    private fun returnType(results: List<Field>): String = returnType(results, false)

    private fun returnType(results: List<Field>, owner: InterfaceDeclaration?): String =
        returnType(results, false, owner)

    private fun returnType(
        results: List<Field>,
        resourceAware: Boolean,
        owner: InterfaceDeclaration? = null,
    ): String {
        if (results.size == 1) {
            return argumentType(results[0].type(), resourceAware, owner)
        }
        val types = ArrayList<String>()
        for (result in results) {
            types.add(argumentType(result.type(), resourceAware, owner))
        }
        return tupleTypeNames(types)
    }

    private fun adapterReturnType(results: List<Field>): String {
        if (results.size == 1) {
            return adapterKotlinType(results[0].type())
        }
        val types = ArrayList<String>()
        for (result in results) {
            types.add(adapterKotlinType(result.type()))
        }
        return tupleTypeNames(types)
    }

    private fun kotlinType(type: TypeRef?): String = kotlinType(type, null)

    private fun kotlinType(type: TypeRef?, owner: InterfaceDeclaration?): String {
        if (type == null) {
            return "Unit"
        }
        if (type.kind() == TypeRef.TypeKind.PRIMITIVE) {
            return primitiveType(type.name()!!)
        }
        if (type.kind() == TypeRef.TypeKind.NAMED) {
            return localUseAliasTypeName(owner, type.name()!!)
                ?: typeName(WitNames.lastSegment(type.name()!!))
        }
        val args = type.arguments()
        return when (type.kind()) {
            TypeRef.TypeKind.LIST ->
                listType(if (args.isEmpty()) TypeRef.primitive("unit") else args[0], false, owner)
            TypeRef.TypeKind.OPTION -> nullable(kotlinType(args[0], owner))
            TypeRef.TypeKind.RESULT -> resultType(args, false, owner)
            TypeRef.TypeKind.TUPLE -> tupleType(args, false, owner)
            TypeRef.TypeKind.FUTURE -> "WitFuture<${optionalArgument(args, false, owner)}>"
            TypeRef.TypeKind.STREAM -> "WitStream<${optionalArgument(args, false, owner)}>"
            TypeRef.TypeKind.BORROW,
            TypeRef.TypeKind.OWN -> optionalArgument(args, false, owner)
            else -> throw IllegalArgumentException("Unsupported WIT type: $type")
        }
    }

    private fun resourceAwareKotlinType(type: TypeRef?): String {
        if (type == null) {
            return "Unit"
        }
        if (type.kind() == TypeRef.TypeKind.PRIMITIVE) {
            return primitiveType(type.name()!!)
        }
        if (type.kind() == TypeRef.TypeKind.NAMED) {
            val typeName = type.name()!!
            if (hasResourceDeclaration(typeName)) {
                return resourceHandleType(WitNames.lastSegment(typeName))
            }
            return typeName(WitNames.lastSegment(typeName))
        }
        val args = type.arguments()
        return when (type.kind()) {
            TypeRef.TypeKind.LIST ->
                listType(if (args.isEmpty()) TypeRef.primitive("unit") else args[0], true)
            TypeRef.TypeKind.OPTION -> nullable(resourceAwareKotlinType(args[0]))
            TypeRef.TypeKind.RESULT -> resultType(args, true)
            TypeRef.TypeKind.TUPLE -> tupleType(args, true)
            TypeRef.TypeKind.FUTURE -> "WitFuture<${optionalArgument(args, true)}>"
            TypeRef.TypeKind.STREAM -> "WitStream<${optionalArgument(args, true)}>"
            TypeRef.TypeKind.BORROW,
            TypeRef.TypeKind.OWN -> optionalArgument(args, true)
            else -> throw IllegalArgumentException("Unsupported WIT type: $type")
        }
    }

    private fun resourceHandleType(resourceType: String): String =
        typeName(WitNames.lastSegment(resourceType))

    private fun primitiveType(name: String): String =
        when (name) {
            "bool" -> "Boolean"
            "s8" -> "Byte"
            "s16" -> "Short"
            "s32" -> "Int"
            "s64" -> "Long"
            "u8" -> "UByte"
            "u16" -> "UShort"
            "u32" -> "UInt"
            "u64" -> "ULong"
            "f32" -> "Float"
            "f64" -> "Double"
            "char" -> "Int"
            "string" -> "String"
            "unit" -> "Unit"
            else -> typeName(name)
        }

    private fun listType(elementType: TypeRef): String = listType(elementType, false)

    private fun listType(
        elementType: TypeRef,
        resourceAware: Boolean,
        owner: InterfaceDeclaration? = null,
    ): String {
        if (elementType.kind() == TypeRef.TypeKind.PRIMITIVE) {
            when (elementType.name()) {
                "s8" -> return "ByteArray"
                "s16" -> return "ShortArray"
                "s32" -> return "IntArray"
                "s64" -> return "LongArray"
                "u8" -> return "UByteArray"
                "u16" -> return "UShortArray"
                "u32" -> return "UIntArray"
                "u64" -> return "ULongArray"
                "f32" -> return "FloatArray"
                "f64" -> return "DoubleArray"
            }
        }
        return "List<${if (resourceAware) resourceAwareKotlinType(elementType) else kotlinType(elementType, owner)}>"
    }

    private fun resultType(args: List<TypeRef>): String = resultType(args, false)

    private fun resultType(
        args: List<TypeRef>,
        resourceAware: Boolean,
        owner: InterfaceDeclaration? = null,
    ): String {
        val ok = if (args.isNotEmpty()) argumentType(args[0], resourceAware, owner) else "Unit"
        val err = if (args.size > 1) argumentType(args[1], resourceAware, owner) else "Unit"
        return "WitResult<$ok, $err>"
    }

    private fun tupleType(args: List<TypeRef>): String = tupleType(args, false)

    private fun tupleType(
        args: List<TypeRef>,
        resourceAware: Boolean,
        owner: InterfaceDeclaration? = null,
    ): String {
        val types = ArrayList<String>()
        for (arg in args) {
            types.add(argumentType(arg, resourceAware, owner))
        }
        return tupleTypeNames(types)
    }

    private fun tupleTypeNames(types: List<String>): String {
        if (types.size == 1) {
            return "WitTuple1<${types[0]}>"
        }
        if (types.size == 2) {
            return "Pair<${types[0]}, ${types[1]}>"
        }
        if (types.size == 3) {
            return "Triple<${types[0]}, ${types[1]}, ${types[2]}>"
        }
        if (types.size in 4..8) {
            return "WitTuple${types.size}<${types.joinToString(", ")}>"
        }
        return "List<Any?>"
    }

    private fun optionalArgument(args: List<TypeRef>): String = optionalArgument(args, false)

    private fun optionalArgument(
        args: List<TypeRef>,
        resourceAware: Boolean,
        owner: InterfaceDeclaration? = null,
    ): String =
        if (args.isEmpty()) "Unit" else argumentType(args[0], resourceAware, owner)

    private fun argumentType(
        type: TypeRef,
        resourceAware: Boolean,
        owner: InterfaceDeclaration? = null,
    ): String =
        if (resourceAware) resourceAwareKotlinType(type) else kotlinType(type, owner)

    private fun nullable(type: String): String = if (type.endsWith("?")) type else "$type?"

    private fun interfaceTypeName(declaration: InterfaceDeclaration): String =
        interfaceTypeNames.getOrDefault(declaration, typeName(declaration.name()))

    private fun worldTypeName(declaration: WorldDeclaration): String =
        worldTypeNames.getOrDefault(declaration, typeName(declaration.name()))

    private fun findInterface(name: String): InterfaceDeclaration? = findInterface(name, null)

    private fun findInterface(name: String, packageContext: String?): InterfaceDeclaration? {
        for (declaration in witPackage.interfaces()) {
            if (declaration.qualifiedName() == name) {
                return declaration
            }
        }
        if (packageContext != null && !name.contains("/") && !name.contains(":")) {
            val qualifiedName = WitNames.qualifiedInterfaceName(packageContext, name)
            for (declaration in witPackage.interfaces()) {
                if (declaration.qualifiedName() == qualifiedName) {
                    return declaration
                }
            }
        }
        if (name.contains("/") || name.contains(":")) {
            return null
        }
        for (declaration in witPackage.interfaces()) {
            if (declaration.name() == name) {
                return declaration
            }
        }
        val normalized = WitNames.lastSegment(name)
        for (declaration in witPackage.interfaces()) {
            if (
                WitNames.lastSegment(declaration.qualifiedName()) == normalized ||
                    WitNames.lastSegment(declaration.name()) == normalized
            ) {
                return declaration
            }
        }
        return null
    }

    private fun localUseAliasTypeName(owner: InterfaceDeclaration?, name: String): String? {
        if (owner == null) {
            return null
        }
        val normalized = normalizeTypeReference(name)
        for (member in owner.members()) {
            if (member !is UseDeclaration) {
                continue
            }
            val targetInterfacePath =
                findInterface(member.path(), owner.packageName())?.qualifiedName()
                    ?: WitNames.qualifiedInterfaceName(owner.packageName(), member.path())
            for (item in member.items()) {
                if (
                    normalizeTypeReference(qualifiedTypeName(targetInterfacePath, item.name())) ==
                        normalized
                ) {
                    return typeName(item.localName())
                }
            }
        }
        return null
    }

    private fun hasTypeDeclaration(name: String): Boolean {
        val normalized = WitNames.lastSegment(name)
        for (declaration in witPackage.declarations()) {
            if (declaration is TypeDeclaration && declaration.name() == normalized) {
                return true
            }
            if (declaration is InterfaceDeclaration) {
                for (member in declaration.members()) {
                    if (member is TypeDeclaration && member.name() == normalized) {
                        return true
                    }
                }
            } else if (declaration is WorldDeclaration) {
                for (member in declaration.declarations()) {
                    if (member is TypeDeclaration && member.name() == normalized) {
                        return true
                    }
                }
            }
        }
        return false
    }

    private fun hasResourceDeclaration(name: String): Boolean {
        val normalized = WitNames.lastSegment(name)
        for (declaration in witPackage.declarations()) {
            if (
                declaration is TypeDeclaration &&
                    declaration.name() == normalized &&
                    declaration.kind() == TypeDeclaration.Kind.RESOURCE
            ) {
                return true
            }
            if (declaration is InterfaceDeclaration) {
                for (member in declaration.members()) {
                    if (
                        member is TypeDeclaration &&
                            member.name() == normalized &&
                            member.kind() == TypeDeclaration.Kind.RESOURCE
                    ) {
                        return true
                    }
                }
            } else if (declaration is WorldDeclaration) {
                for (member in declaration.declarations()) {
                    if (
                        member is TypeDeclaration &&
                            member.name() == normalized &&
                            member.kind() == TypeDeclaration.Kind.RESOURCE
                    ) {
                        return true
                    }
                }
            }
        }
        return false
    }

    private fun appendGuestExportAdapters(out: StringBuilder) {
        val bindings = guestExportBindings()
        if (bindings.isEmpty()) {
            return
        }
        val hasAsyncExport = bindings.any { it.function.isAsync }
        out.append("\n")
        out.append("public object KrwaGuestExports {\n")
        for (world in witPackage.worlds()) {
            if (world.exports().isEmpty()) {
                continue
            }
            out.append("  public lateinit var ")
                .append(memberName(world.name()))
                .append(": ")
                .append(worldTypeName(world))
                .append(".Guest\n")
            out.append("  public fun install")
                .append(worldTypeName(world))
                .append("(guest: ")
                .append(worldTypeName(world))
                .append(".Guest) {\n")
            out.append("    this.").append(memberName(world.name())).append(" = guest\n")
            out.append("  }\n")
        }
        out.append("}\n\n")
        appendGuestExportRuntime(out, hasAsyncExport)
        appendGuestExportStoreHelpers(out)
        val usedNames = LinkedHashMap<String, Int>()
        val taskReturnFunctions =
            if (hasAsyncExport) appendGuestTaskReturnImports(out, bindings) else emptyMap()
        for (binding in bindings) {
            if (binding.function.isAsync) {
                appendGuestAsyncExportFunction(
                    out,
                    binding,
                    binding.asyncExport,
                    taskReturnFunctions.getValue(binding.asyncExport.taskReturn),
                    usedNames,
                )
            } else {
                for (exportName in binding.exportNames) {
                    appendGuestExportFunction(out, binding, exportName, usedNames)
                }
            }
        }
    }

    private fun appendGuestExportRuntime(out: StringBuilder, hasAsyncExport: Boolean) {
        out.append("@WasmExport(\"canonical_abi_realloc\")\n")
        out.append(
            "public fun canonicalAbiRealloc(originalPtr: Int, originalSize: Int, align: Int," +
                " newSize: Int): Int =\n"
        )
        out.append("  componentModelRealloc(originalPtr, originalSize, newSize)\n\n")
        out.append("@WasmExport(\"cabi_realloc\")\n")
        out.append(
            "public fun cabiRealloc(originalPtr: Int, originalSize: Int, align: Int," +
                " newSize: Int): Int =\n"
        )
        out.append("  componentModelRealloc(originalPtr, originalSize, newSize)\n\n")
        out.append("private fun <T> krwaRunSuspend(block: suspend () -> T): T {\n")
        out.append("  var outcome: Result<T>? = null\n")
        out.append("  block.startCoroutine(object : Continuation<T> {\n")
        out.append("    override val context = EmptyCoroutineContext\n")
        out.append("    override fun resumeWith(result: Result<T>) {\n")
        out.append("      outcome = result\n")
        out.append("    }\n")
        out.append("  })\n")
        out.append(
            "  val completed = outcome ?: error(\"WIT guest export suspended; async export" +
                " callbacks are not available for this adapter\")\n"
        )
        out.append("  return completed.getOrThrow()\n")
        out.append("}\n\n")
        if (hasAsyncExport) {
            out.append("@WasmImport(\"\\${'$'}root\", \"[context-get-0]\")\n")
            out.append("private external fun krwaContextGet0(): Int\n\n")
            out.append("@WasmImport(\"\\${'$'}root\", \"[context-set-0]\")\n")
            out.append("private external fun krwaContextSet0(value: Int)\n\n")
            out.append("private const val KRWA_ASYNC_EXIT: Int = 0\n")
            out.append("private const val KRWA_ASYNC_YIELD: Int = 1\n\n")
            out.append("private class KrwaAsyncState<T>(val onReturn: (T) -> Unit) {\n")
            out.append("  var outcome: Result<T>? = null\n")
            out.append("}\n\n")
            out.append(
                "private val krwaAsyncStates = ArrayList<KrwaAsyncState<Any?>?>()\n"
            )
            out.append("private val krwaFreeAsyncStateIds = ArrayList<Int>()\n\n")
            out.append("@Suppress(\"UNCHECKED_CAST\")\n")
            out.append(
                "private fun <T> krwaStoreAsyncState(state: KrwaAsyncState<T>): Int {\n"
            )
            out.append("  val erased = state as KrwaAsyncState<Any?>\n")
            out.append("  if (krwaFreeAsyncStateIds.isNotEmpty()) {\n")
            out.append("    val id = krwaFreeAsyncStateIds.removeAt(krwaFreeAsyncStateIds.size - 1)\n")
            out.append("    krwaAsyncStates[id] = erased\n")
            out.append("    return id\n")
            out.append("  }\n")
            out.append("  krwaAsyncStates.add(erased)\n")
            out.append("  return krwaAsyncStates.size - 1\n")
            out.append("}\n\n")
            out.append("private fun <T> krwaStartSuspend(\n")
            out.append("  onReturn: (T) -> Unit,\n")
            out.append("  block: suspend () -> T,\n")
            out.append("): Int {\n")
            out.append("  val state = KrwaAsyncState(onReturn)\n")
            out.append("  val id = krwaStoreAsyncState(state)\n")
            out.append("  krwaContextSet0(id)\n")
            out.append("  krwaFreeAllComponentModelReallocAllocatedMemory()\n")
            out.append("  block.startCoroutine(object : Continuation<T> {\n")
            out.append("    override val context = EmptyCoroutineContext\n")
            out.append("    override fun resumeWith(result: Result<T>) {\n")
            out.append("      state.outcome = result\n")
            out.append("    }\n")
            out.append("  })\n")
            out.append("  return krwaPollAsyncState(id)\n")
            out.append("}\n\n")
            out.append("private fun krwaResumeSuspend(): Int {\n")
            out.append("  val id = krwaContextGet0()\n")
            out.append("  krwaFreeAllComponentModelReallocAllocatedMemory()\n")
            out.append("  return krwaPollAsyncState(id)\n")
            out.append("}\n\n")
            out.append("private fun krwaPollAsyncState(id: Int): Int {\n")
            out.append(
                "  val state = krwaAsyncStates.getOrNull(id) ?: error(\"unknown WIT async" +
                    " guest export task\")\n"
            )
            out.append("  val completed = state.outcome ?: return KRWA_ASYNC_YIELD\n")
            out.append("  krwaAsyncStates[id] = null\n")
            out.append("  krwaFreeAsyncStateIds.add(id)\n")
            out.append("  krwaFreeAllComponentModelReallocAllocatedMemory()\n")
            out.append("  state.onReturn(completed.getOrThrow())\n")
            out.append("  return KRWA_ASYNC_EXIT\n")
            out.append("}\n\n")
        }
        out.append("private fun krwaFreeAllComponentModelReallocAllocatedMemory() {\n")
        out.append("  freeAllComponentModelReallocAllocatedMemory()\n")
        out.append("}\n\n")
        out.append("private fun krwaResetOutputHeap() = Unit\n\n")
        out.append("private fun krwaAlloc(size: Int): Int {\n")
        out.append("  val allocationSize = size.coerceAtLeast(0)\n")
        out.append("  if (allocationSize == 0) return 0\n")
        out.append("  return componentModelRealloc(0, 0, allocationSize)\n")
        out.append("}\n\n")
        out.append("private fun krwaAlignTo(value: Int, alignment: Int): Int {\n")
        out.append("  if (alignment <= 1) return value\n")
        out.append("  val remainder = value % alignment\n")
        out.append("  return if (remainder == 0) value else value + alignment - remainder\n")
        out.append("}\n\n")
        out.append("private fun krwaLoadI8(ptr: Int): Byte = Pointer(ptr.toUInt()).loadByte()\n\n")
        out.append("private fun krwaLoadI16(ptr: Int): Short = Pointer(ptr.toUInt()).loadShort()\n\n")
        out.append("private fun krwaLoadI32(ptr: Int): Int = Pointer(ptr.toUInt()).loadInt()\n\n")
        out.append("private fun krwaLoadI64(ptr: Int): Long = Pointer(ptr.toUInt()).loadLong()\n\n")
        out.append("private fun krwaLoadF32(ptr: Int): Float = Float.fromBits(krwaLoadI32(ptr))\n\n")
        out.append("private fun krwaLoadF64(ptr: Int): Double = Double.fromBits(krwaLoadI64(ptr))\n\n")
        out.append("private fun krwaStoreI8(ptr: Int, value: Byte) {\n")
        out.append("  Pointer(ptr.toUInt()).storeByte(value)\n")
        out.append("}\n\n")
        out.append("private fun krwaStoreI16(ptr: Int, value: Short) {\n")
        out.append("  Pointer(ptr.toUInt()).storeShort(value)\n")
        out.append("}\n\n")
        out.append("private fun krwaStoreI32(ptr: Int, value: Int) {\n")
        out.append("  Pointer(ptr.toUInt()).storeInt(value)\n")
        out.append("}\n\n")
        out.append("private fun krwaStoreI64(ptr: Int, value: Long) {\n")
        out.append("  Pointer(ptr.toUInt()).storeLong(value)\n")
        out.append("}\n\n")
        out.append("private fun krwaStoreF32(ptr: Int, value: Float) {\n")
        out.append("  krwaStoreI32(ptr, value.toBits())\n")
        out.append("}\n\n")
        out.append("private fun krwaStoreF64(ptr: Int, value: Double) {\n")
        out.append("  krwaStoreI64(ptr, value.toBits())\n")
        out.append("}\n\n")
        out.append("private fun krwaLoadString(ptr: Int, len: Int): String {\n")
        out.append("  val bytes = ByteArray(len)\n")
        out.append("  var index = 0\n")
        out.append("  while (index < len) {\n")
            out.append("    bytes[index] = Pointer((ptr + index).toUInt()).loadByte()\n")
        out.append("    index++\n")
        out.append("  }\n")
        out.append("  return bytes.decodeToString()\n")
        out.append("}\n\n")
        out.append("private fun krwaStoreBytes(bytes: ByteArray): Int {\n")
        out.append("  val ptr = krwaAlloc(bytes.size)\n")
        out.append("  var index = 0\n")
        out.append("  while (index < bytes.size) {\n")
        out.append("    Pointer((ptr + index).toUInt()).storeByte(bytes[index])\n")
        out.append("    index++\n")
        out.append("  }\n")
        out.append("  return ptr\n")
        out.append("}\n\n")
        out.append("private fun krwaStoreString(ptr: Int, value: String) {\n")
        out.append("  val bytes = value.encodeToByteArray()\n")
        out.append("  val bytesPtr = krwaStoreBytes(bytes)\n")
        out.append("  krwaStoreI32(ptr, bytesPtr)\n")
        out.append("  krwaStoreI32(ptr + 4, bytes.size)\n")
        out.append("}\n\n")
        out.append("private fun krwaStoreOptionString(ptr: Int, value: String?) {\n")
        out.append("  if (value == null) {\n")
        out.append("    krwaStoreI8(ptr, 0.toByte())\n")
        out.append("    return\n")
        out.append("  }\n")
        out.append("  krwaStoreI8(ptr, 1.toByte())\n")
        out.append("  krwaStoreString(krwaAlignTo(ptr + 1, 4), value)\n")
        out.append("}\n\n")
        out.append("private fun krwaStoreOptionInt(ptr: Int, value: Int?) {\n")
        out.append("  if (value == null) {\n")
        out.append("    krwaStoreI8(ptr, 0.toByte())\n")
        out.append("    return\n")
        out.append("  }\n")
        out.append("  krwaStoreI8(ptr, 1.toByte())\n")
        out.append("  krwaStoreI32(krwaAlignTo(ptr + 1, 4), value)\n")
        out.append("}\n\n")
        out.append("private fun krwaStoreStringList(value: List<String>): Int {\n")
        out.append("  val ptr = krwaAlloc(8 * value.size)\n")
        out.append("  var index = 0\n")
        out.append("  while (index < value.size) {\n")
        out.append("    krwaStoreString(ptr + (index * 8), value[index])\n")
        out.append("    index++\n")
        out.append("  }\n")
        out.append("  return ptr\n")
        out.append("}\n\n")
        out.append("private fun krwaLoadUByteArray(ptr: Int, len: Int): UByteArray {\n")
        out.append("  val bytes = UByteArray(len)\n")
        out.append("  var index = 0\n")
        out.append("  while (index < len) {\n")
        out.append("    bytes[index] = Pointer((ptr + index).toUInt()).loadByte().toUByte()\n")
        out.append("    index++\n")
        out.append("  }\n")
        out.append("  return bytes\n")
        out.append("}\n\n")
        out.append("private fun krwaLoadByteArray(ptr: Int, len: Int): ByteArray {\n")
        out.append("  val bytes = ByteArray(len)\n")
        out.append("  var index = 0\n")
        out.append("  while (index < len) {\n")
        out.append("    bytes[index] = Pointer((ptr + index).toUInt()).loadByte()\n")
        out.append("    index++\n")
        out.append("  }\n")
        out.append("  return bytes\n")
        out.append("}\n\n")
    }

    private fun appendGuestExportStoreHelpers(out: StringBuilder) {
        for ((declaration, helper) in guestExportStoreHelpers) {
            val typeName = adapterTypeName(declaration)
            out.append("private fun ")
                .append(helper.storeFunctionName)
                .append("(ptr: Int, value: ")
                .append(typeName)
                .append(") {\n")
            for (line in storeRecordLines("value", declaration.fields(), "ptr", helper.storeFunctionName)) {
                out.append("  ").append(line).append("\n")
            }
            out.append("}\n\n")

            val stride = sizeOfFields(declaration.fields())
            out.append("private fun ")
                .append(helper.storeListFunctionName)
                .append("(value: List<")
                .append(typeName)
                .append(">): Int {\n")
            out.append("  val ptr = krwaAlloc($stride * value.size)\n")
            out.append("  var index = 0\n")
            out.append("  while (index < value.size) {\n")
            out.append("    ")
                .append(helper.storeFunctionName)
                .append("(ptr + (index * $stride), value[index])\n")
            out.append("    index++\n")
            out.append("  }\n")
            out.append("  return ptr\n")
            out.append("}\n\n")
        }
    }

    private fun appendGuestTaskReturnImports(
        out: StringBuilder,
        bindings: List<GuestExportBinding>,
    ): Map<GuestTaskReturn, String> {
        val taskReturns = LinkedHashMap<GuestTaskReturn, String>()
        val usedNames = LinkedHashMap<String, Int>()
        for (binding in bindings) {
            val taskReturn = binding.asyncExport.taskReturn
            if (taskReturns.containsKey(taskReturn)) {
                continue
            }
            val functionName =
                uniqueGeneratedFunctionName(
                    "__krwa_task_return_${taskReturn.module}.${taskReturn.name}",
                    usedNames,
                )
            taskReturns[taskReturn] = functionName
            out.append("@WasmImport(")
                .append(kotlinString(taskReturn.module))
                .append(", ")
                .append(kotlinString(taskReturn.name))
                .append(")\n")
            out.append("private external fun ").append(functionName).append("(")
            val params = taskReturnParamTypes(binding.function)
            for (index in params.indices) {
                if (index > 0) {
                    out.append(", ")
                }
                out.append("arg").append(index).append(": ").append(coreKotlinType(params[index]))
            }
            out.append(")\n\n")
        }
        return taskReturns
    }

    private fun appendGuestExportFunction(
        out: StringBuilder,
        binding: GuestExportBinding,
        exportName: String,
        usedNames: MutableMap<String, Int>,
    ) {
        val type = canonicalAbi.coreFunctionType(binding.function, CanonicalAbi.Direction.LIFTED_EXPORT)
        val functionName = uniqueGuestExportFunctionName(exportName, usedNames)
        out.append("@WasmExport(").append(kotlinString(exportName)).append(")\n")
        out.append("public fun ").append(functionName).append("(")
        for (index in type.params().indices) {
            if (index > 0) {
                out.append(", ")
            }
            out.append("arg").append(index).append(": ").append(coreKotlinType(type.params()[index]))
        }
        out.append(")")
        if (type.returns().isNotEmpty()) {
            out.append(": ").append(coreKotlinType(type.returns()[0]))
        }
        out.append(" {\n")
        val body = guestExportBody(binding)
        for (line in body.lines()) {
            out.append("  ").append(line).append("\n")
        }
        out.append("}\n\n")
        appendGuestExportPostReturn(out, exportName, type.returns(), usedNames)
    }

    private fun appendGuestAsyncExportFunction(
        out: StringBuilder,
        binding: GuestExportBinding,
        asyncExport: GuestAsyncExport,
        taskReturnFunctionName: String,
        usedNames: MutableMap<String, Int>,
    ) {
        val type = asyncGuestExportType(binding.function)
        val functionName = uniqueGuestExportFunctionName(asyncExport.exportName, usedNames)
        out.append("@WasmExport(").append(kotlinString(asyncExport.exportName)).append(")\n")
        out.append("public fun ").append(functionName).append("(")
        for (index in type.params().indices) {
            if (index > 0) {
                out.append(", ")
            }
            out.append("arg").append(index).append(": ").append(coreKotlinType(type.params()[index]))
        }
        out.append("): Int {\n")
        val body = guestAsyncExportBody(binding, taskReturnFunctionName)
        for (line in body.lines()) {
            out.append("  ").append(line).append("\n")
        }
        out.append("}\n\n")

        val callbackName = uniqueGuestExportFunctionName(asyncExport.callbackExportName, usedNames)
        out.append("@WasmExport(").append(kotlinString(asyncExport.callbackExportName)).append(")\n")
        out.append(
            "public fun $callbackName(event: Int, payload1: Int, payload2: Int): Int =\n"
        )
        out.append("  krwaResumeSuspend()\n\n")
    }

    private fun asyncGuestExportType(function: Function): FunctionType {
        val syncType = canonicalAbi.coreFunctionType(function, CanonicalAbi.Direction.LIFTED_EXPORT)
        return FunctionType.of(syncType.params(), listOf(ValType.I32))
    }

    private fun appendGuestExportPostReturn(
        out: StringBuilder,
        exportName: String,
        returns: List<ValType>,
        usedNames: MutableMap<String, Int>,
    ) {
        if (returns.isEmpty()) {
            return
        }
        val functionName = uniqueGuestExportFunctionName("cabi_post_$exportName", usedNames)
        out.append("@WasmExport(").append(kotlinString("cabi_post_$exportName")).append(")\n")
        out.append("public fun ").append(functionName).append("(")
        for (index in returns.indices) {
            if (index > 0) {
                out.append(", ")
            }
            out.append("ret").append(index).append(": ").append(coreKotlinType(returns[index]))
        }
        out.append(") {\n")
        out.append("  krwaFreeAllComponentModelReallocAllocatedMemory()\n")
        out.append("}\n\n")
    }

    private fun guestExportBody(binding: GuestExportBinding): String {
        val parameters = guestExportParameters(binding.function)
        val lines = ArrayList(parameters.lines)
        val args = parameters.arguments
        lines.add("krwaFreeAllComponentModelReallocAllocatedMemory()")
        lines.add("krwaResetOutputHeap()")

        val resultExpression = guestInvocation(binding, args)
        if (binding.function.results().isEmpty()) {
            lines.add(resultExpression)
            lines.add("return")
            return lines.joinToString("\n")
        }

        lines.add("val result = $resultExpression")
        val resultFields = binding.function.results()
        val resultValues = resultValueExpressions(resultFields, "result")
        val flatResultCount = flatFieldCount(resultFields)
        if (flatResultCount > CanonicalAbi.MAX_FLAT_RESULTS) {
            val resultSize = sizeOfFields(resultFields)
            lines.add("val resultPtr = krwaAlloc($resultSize)")
            var offset = 0
            for (index in resultFields.indices) {
                val field = resultFields[index]
                offset = alignTo(offset, canonicalAbi.alignment(field.type()))
                for (
                    line in
                        storeValueLines(
                            resultValues[index],
                            field.type(),
                            "resultPtr + $offset",
                            "result$index",
                        )
                ) {
                    lines.add(line)
                }
                offset += canonicalAbi.elementSize(field.type())
            }
            lines.add("return resultPtr")
            return lines.joinToString("\n")
        }

        if (flatResultCount == 0) {
            lines.add("return")
            return lines.joinToString("\n")
        }

        val lowered = lowerFlatExpressions(resultValues[0], resultFields[0].type(), "result0")
        lines.addAll(lowered.lines)
        lines.add("return ${lowered.expressions[0]}")
        return lines.joinToString("\n")
    }

    private fun guestAsyncExportBody(
        binding: GuestExportBinding,
        taskReturnFunctionName: String,
    ): String {
        val parameters = guestExportParameters(binding.function)
        val lines = ArrayList(parameters.lines)
        lines.add("krwaFreeAllComponentModelReallocAllocatedMemory()")
        val resultType =
            if (binding.function.results().isEmpty()) {
                "Unit"
            } else {
                adapterReturnType(binding.function.results())
        }
        lines.add("return krwaStartSuspend(")
        lines.add("  { result: $resultType ->")
        lines.add("    krwaResetOutputHeap()")
        for (line in guestTaskReturnLines(binding.function, taskReturnFunctionName)) {
            lines.add("    $line")
        }
        lines.add("  }")
        lines.add(") {")
        lines.add("  ${guestInvocation(binding, parameters.arguments, wrapSuspend = false)}")
        lines.add("}")
        return lines.joinToString("\n")
    }

    private fun guestTaskReturnLines(
        function: Function,
        taskReturnFunctionName: String,
    ): List<String> {
        val lines = ArrayList<String>()
        val resultFields = function.results()
        val flatResultCount = flatFieldCount(resultFields)
        if (flatResultCount > CanonicalAbi.MAX_FLAT_PARAMS) {
            val resultValues = resultValueExpressions(resultFields, "result")
            val resultSize = sizeOfFields(resultFields)
            lines.add("val resultPtr = krwaAlloc($resultSize)")
            var offset = 0
            for (index in resultFields.indices) {
                val field = resultFields[index]
                offset = alignTo(offset, canonicalAbi.alignment(field.type()))
                lines.addAll(
                    storeValueLines(
                        resultValues[index],
                        field.type(),
                        "resultPtr + $offset",
                        "result$index",
                    )
                )
                offset += canonicalAbi.elementSize(field.type())
            }
            lines.add("$taskReturnFunctionName(resultPtr)")
            lines.add("krwaFreeAllComponentModelReallocAllocatedMemory()")
            return lines
        }

        val expressions = ArrayList<String>()
        if (flatResultCount > 0) {
            val resultValues = resultValueExpressions(resultFields, "result")
            for (index in resultFields.indices) {
                val field = resultFields[index]
                val lowered = lowerFlatExpressions(resultValues[index], field.type(), "result$index")
                lines.addAll(lowered.lines)
                expressions.addAll(lowered.expressions)
            }
        }
        lines.add("$taskReturnFunctionName(${expressions.joinToString(", ")})")
        lines.add("krwaFreeAllComponentModelReallocAllocatedMemory()")
        return lines
    }

    private fun guestExportParameters(function: Function): GeneratedParameters {
        val lines = ArrayList<String>()
        val args = ArrayList<String>()
        val fields = function.parameters()
        if (flatFieldCount(fields) > CanonicalAbi.MAX_FLAT_PARAMS) {
            var offset = 0
            for (index in fields.indices) {
                val field = fields[index]
                offset = alignTo(offset, canonicalAbi.alignment(field.type()))
                val lifted = liftMemoryExpression(field.type(), "arg0 + $offset", "param$index")
                lines.addAll(lifted.lines)
                val name = "param$index"
                lines.add("val $name: ${adapterKotlinType(field.type())} = ${lifted.expression}")
                args.add(name)
                offset += canonicalAbi.elementSize(field.type())
            }
        } else {
            val cursor = ArgCursor()
            for (index in fields.indices) {
                val field = fields[index]
                val lifted = liftFlatExpression(field.type(), cursor, "param$index")
                lines.addAll(lifted.lines)
                val name = "param$index"
                lines.add("val $name: ${adapterKotlinType(field.type())} = ${lifted.expression}")
                args.add(name)
            }
        }
        return GeneratedParameters(lines, args)
    }

    private fun guestInvocation(
        binding: GuestExportBinding,
        args: List<String>,
        wrapSuspend: Boolean = true,
    ): String {
        val invocation =
            "KrwaGuestExports." +
                memberName(binding.world.name()) +
                binding.receiverPath +
                "." +
                memberName(binding.function.name()) +
                "(" +
                args.joinToString(", ") +
                ")"
        return if (wrapSuspend && binding.function.isAsync) "krwaRunSuspend { $invocation }" else invocation
    }

    private fun resultValueExpressions(fields: List<Field>, resultName: String): List<String> {
        if (fields.size == 1) {
            return listOf(resultName)
        }
        val result = ArrayList<String>()
        for (index in fields.indices) {
            result.add("$resultName.${tupleAccessor(index)}")
        }
        return result
    }

    private fun flatFieldCount(fields: List<Field>): Int {
        var count = 0
        for (field in fields) {
            count += canonicalAbi.flattenType(field.type()).size
        }
        return count
    }

    private fun taskReturnParamTypes(function: Function): List<ValType> {
        val resultFields = function.results()
        if (flatFieldCount(resultFields) > CanonicalAbi.MAX_FLAT_PARAMS) {
            return listOf(ValType.I32)
        }
        val result = ArrayList<ValType>()
        for (field in resultFields) {
            for (type in canonicalAbi.flattenType(field.type())) {
                result.add(type.valType())
            }
        }
        return result
    }

    private fun sizeOfFields(fields: List<Field>): Int {
        var size = 0
        var alignment = 1
        for (field in fields) {
            alignment = maxOf(alignment, canonicalAbi.alignment(field.type()))
        }
        for (field in fields) {
            size = alignTo(size, canonicalAbi.alignment(field.type()))
            size += canonicalAbi.elementSize(field.type())
        }
        return alignTo(size, alignment)
    }

    private fun alignTo(value: Int, alignment: Int): Int {
        if (alignment <= 1) {
            return value
        }
        val remainder = value % alignment
        return if (remainder == 0) value else value + alignment - remainder
    }

    private fun adapterKotlinType(type: TypeRef?): String {
        if (type == null) {
            return "Unit"
        }
        if (type.kind() == TypeRef.TypeKind.PRIMITIVE) {
            return primitiveType(type.name()!!)
        }
        if (type.kind() == TypeRef.TypeKind.NAMED) {
            return adapterTypeName(type.name()!!)
        }
        val args = type.arguments()
        return when (type.kind()) {
            TypeRef.TypeKind.LIST ->
                adapterListType(if (args.isEmpty()) TypeRef.primitive("unit") else args[0])
            TypeRef.TypeKind.OPTION -> nullable(adapterKotlinType(args[0]))
            TypeRef.TypeKind.RESULT -> adapterResultType(args)
            TypeRef.TypeKind.TUPLE -> adapterTupleType(args)
            TypeRef.TypeKind.FUTURE -> "WitFuture<${adapterOptionalArgument(args)}>"
            TypeRef.TypeKind.STREAM -> "WitStream<${adapterOptionalArgument(args)}>"
            TypeRef.TypeKind.BORROW,
            TypeRef.TypeKind.OWN -> adapterOptionalArgument(args)
            else -> throw IllegalArgumentException("Unsupported WIT type: $type")
        }
    }

    private fun adapterTypeName(name: String): String {
        val normalized = normalizeTypeReference(name)
        val simpleName = WitNames.lastSegment(normalized)
        for (declaration in witPackage.declarations()) {
            if (
                declaration is TypeDeclaration &&
                    typeMatches(declaration.name(), name, normalized, simpleName)
            ) {
                return typeName(declaration.name())
            }
            if (declaration is UseDeclaration) {
                val found = adapterUseTypeName(null, declaration, name, normalized, simpleName)
                if (found != null) {
                    return found
                }
            }
            if (declaration is InterfaceDeclaration) {
                for (member in declaration.members()) {
                    if (
                        member is TypeDeclaration &&
                            (
                                typeMatches(
                                    qualifiedTypeName(declaration.qualifiedName(), member.name()),
                                    name,
                                    normalized,
                                    simpleName,
                                ) ||
                                    typeMatches(member.name(), name, normalized, simpleName)
                                )
                    ) {
                        return interfaceTypeName(declaration) + "." + typeName(member.name())
                    }
                    if (member is UseDeclaration) {
                        val found =
                            adapterUseTypeName(
                                interfaceTypeName(declaration),
                                member,
                                name,
                                normalized,
                                simpleName,
                            )
                        if (found != null) {
                            return found
                        }
                    }
                }
            } else if (declaration is WorldDeclaration) {
                for (member in declaration.declarations()) {
                    if (
                        member is TypeDeclaration &&
                            (
                                typeMatches(
                                    qualifiedTypeName(declaration.qualifiedName(), member.name()),
                                    name,
                                    normalized,
                                    simpleName,
                                ) ||
                                    typeMatches(member.name(), name, normalized, simpleName)
                                )
                    ) {
                        return worldTypeName(declaration) + "." + typeName(member.name())
                    }
                    if (member is UseDeclaration) {
                        val found =
                            adapterUseTypeName(
                                worldTypeName(declaration),
                                member,
                                name,
                                normalized,
                                simpleName,
                            )
                        if (found != null) {
                            return found
                        }
                    }
                }
            }
        }
        return typeName(simpleName)
    }

    private fun adapterTypeName(declaration: TypeDeclaration): String {
        for (candidate in witPackage.declarations()) {
            if (candidate === declaration) {
                return typeName(declaration.name())
            }
            if (candidate is InterfaceDeclaration) {
                for (member in candidate.members()) {
                    if (member === declaration) {
                        return interfaceTypeName(candidate) + "." + typeName(declaration.name())
                    }
                }
            } else if (candidate is WorldDeclaration) {
                for (member in candidate.declarations()) {
                    if (member === declaration) {
                        return worldTypeName(candidate) + "." + typeName(declaration.name())
                    }
                }
            }
        }
        return adapterTypeName(declaration.name())
    }

    private fun adapterUseTypeName(
        qualifier: String?,
        use: UseDeclaration,
        name: String,
        normalized: String,
        simpleName: String,
    ): String? {
        for (item in use.items()) {
            if (
                typeMatches(item.localName(), name, normalized, simpleName) ||
                    typeMatches(item.name(), name, normalized, simpleName) ||
                    typeMatches(
                        qualifiedTypeName(use.path(), item.name()),
                        name,
                        normalized,
                        simpleName,
                    ) ||
                    typeMatches(use.path() + "." + item.name(), name, normalized, simpleName)
            ) {
                val localName = typeName(item.localName())
                return if (qualifier == null) localName else "$qualifier.$localName"
            }
        }
        return null
    }

    private fun typeMatches(
        candidate: String,
        original: String,
        normalized: String,
        simpleName: String,
    ): Boolean {
        val candidateNormalized = normalizeTypeReference(candidate)
        if (isQualifiedTypeReference(original) || isQualifiedTypeReference(normalized)) {
            return candidateNormalized == normalized
        }
        return candidateNormalized == normalized || WitNames.lastSegment(candidateNormalized) == simpleName
    }

    private fun normalizeTypeReference(name: String): String =
        WitNames.withoutVersion(WitNames.stripIdentifierEscape(name))

    private fun qualifiedTypeName(interfacePath: String, typeName: String): String =
        interfacePath + "/" + WitNames.stripIdentifierEscape(typeName)

    private fun isQualifiedTypeReference(name: String): Boolean =
        name.contains("/") || name.contains(":") || name.contains(".")

    private fun adapterListType(elementType: TypeRef): String {
        if (elementType.kind() == TypeRef.TypeKind.PRIMITIVE) {
            when (elementType.name()) {
                "s8" -> return "ByteArray"
                "s16" -> return "ShortArray"
                "s32" -> return "IntArray"
                "s64" -> return "LongArray"
                "u8" -> return "UByteArray"
                "u16" -> return "UShortArray"
                "u32" -> return "UIntArray"
                "u64" -> return "ULongArray"
                "f32" -> return "FloatArray"
                "f64" -> return "DoubleArray"
            }
        }
        return "List<${adapterKotlinType(elementType)}>"
    }

    private fun adapterResultType(args: List<TypeRef>): String {
        val ok = if (args.isNotEmpty()) adapterKotlinType(args[0]) else "Unit"
        val err = if (args.size > 1) adapterKotlinType(args[1]) else "Unit"
        return "WitResult<$ok, $err>"
    }

    private fun adapterTupleType(args: List<TypeRef>): String {
        val types = ArrayList<String>()
        for (arg in args) {
            types.add(adapterKotlinType(arg))
        }
        return tupleTypeNames(types)
    }

    private fun adapterOptionalArgument(args: List<TypeRef>): String =
        if (args.isEmpty()) "Unit" else adapterKotlinType(args[0])

    private fun tupleAccessor(index: Int): String =
        when (index) {
            0 -> "first"
            1 -> "second"
            2 -> "third"
            3 -> "fourth"
            4 -> "fifth"
            5 -> "sixth"
            6 -> "seventh"
            7 -> "eighth"
            else -> "get($index)"
        }

    private fun liftFlatExpression(
        type: TypeRef,
        cursor: ArgCursor,
        hint: String,
    ): GeneratedExpression {
        val resolved = resolveAlias(type)
        if (resolved.kind() == TypeRef.TypeKind.PRIMITIVE) {
            return liftPrimitiveFlatExpression(resolved.name()!!, cursor)
        }
        if (resolved.kind() == TypeRef.TypeKind.NAMED) {
            val declaration = findTypeDeclaration(resolved.name()!!)
            if (declaration != null) {
                return liftNamedFlatExpression(declaration, type, cursor, hint)
            }
        }
        return when (resolved.kind()) {
            TypeRef.TypeKind.LIST -> {
                val ptr = "arg${cursor.next++}"
                val len = "arg${cursor.next++}"
                liftListRangeExpression(firstArgument(resolved), ptr, len, hint)
            }
            TypeRef.TypeKind.OPTION,
            TypeRef.TypeKind.RESULT -> liftConstructedVariantFlatExpression(resolved, cursor, hint)
            TypeRef.TypeKind.TUPLE -> liftTupleFlatExpression(resolved.arguments(), cursor, hint)
            TypeRef.TypeKind.FUTURE ->
                GeneratedExpression(
                    emptyList(),
                    "WitFuture.of<${adapterOptionalArgument(resolved.arguments())}>(arg${cursor.next++}.toLong())",
                )
            TypeRef.TypeKind.STREAM ->
                GeneratedExpression(
                    emptyList(),
                    "WitStream.of<${adapterOptionalArgument(resolved.arguments())}>(arg${cursor.next++}.toLong())",
                )
            TypeRef.TypeKind.BORROW,
            TypeRef.TypeKind.OWN -> {
                val handle = "arg${cursor.next++}"
                if (resolved.arguments().isNotEmpty()) {
                    val target = resolved.arguments()[0]
                    val targetDeclaration =
                        if (target.kind() == TypeRef.TypeKind.NAMED) {
                            findTypeDeclaration(target.name()!!)
                        } else {
                            null
                        }
                    if (targetDeclaration != null && targetDeclaration.kind() == TypeDeclaration.Kind.RESOURCE) {
                        GeneratedExpression(emptyList(), "WitResource($handle.toUInt())")
                    } else {
                        GeneratedExpression(emptyList(), "$handle.toLong()")
                    }
                } else {
                    GeneratedExpression(emptyList(), "$handle.toLong()")
                }
            }
            else -> unsupportedGeneratedExpression(resolved)
        }
    }

    private fun liftPrimitiveFlatExpression(name: String, cursor: ArgCursor): GeneratedExpression =
        when (name) {
            "unit" -> GeneratedExpression(emptyList(), "Unit")
            "string" -> {
                val ptr = "arg${cursor.next++}"
                val len = "arg${cursor.next++}"
                GeneratedExpression(emptyList(), "krwaLoadString($ptr, $len)")
            }
            else -> {
                val value = "arg${cursor.next++}"
                GeneratedExpression(emptyList(), coreToKotlin(value, TypeRef.primitive(name)))
            }
        }

    private fun liftNamedFlatExpression(
        declaration: TypeDeclaration,
        originalType: TypeRef,
        cursor: ArgCursor,
        hint: String,
    ): GeneratedExpression =
        when (declaration.kind()) {
            TypeDeclaration.Kind.ALIAS -> liftFlatExpression(declaration.target()!!, cursor, hint)
            TypeDeclaration.Kind.RESOURCE ->
                GeneratedExpression(emptyList(), "WitResource(arg${cursor.next++}.toUInt())")
            TypeDeclaration.Kind.RECORD ->
                liftRecordFlatExpression(
                    adapterKotlinType(originalType),
                    declaration.fields(),
                    cursor,
                    hint,
                )
            TypeDeclaration.Kind.FLAGS ->
                liftFlagsFlatExpression(adapterKotlinType(originalType), declaration.cases(), cursor)
            TypeDeclaration.Kind.ENUM ->
                GeneratedExpression(
                    emptyList(),
                    "${adapterKotlinType(originalType)}.entries[arg${cursor.next++}]",
                )
            TypeDeclaration.Kind.VARIANT ->
                liftVariantFlatExpression(
                    adapterKotlinType(originalType),
                    declarationCases(declaration),
                    cursor,
                    hint,
                )
        }

    private fun liftRecordFlatExpression(
        typeName: String,
        fields: List<Field>,
        cursor: ArgCursor,
        hint: String,
    ): GeneratedExpression {
        val lines = ArrayList<String>()
        val args = ArrayList<String>()
        for (index in fields.indices) {
            val field = fields[index]
            val lifted = liftFlatExpression(field.type(), cursor, "${hint}_${memberName(field.name())}")
            lines.addAll(lifted.lines)
            args.add(memberName(field.name()) + " = " + lifted.expression)
        }
        return GeneratedExpression(lines, "$typeName(${args.joinToString(", ")})")
    }

    private fun liftTupleFlatExpression(
        types: List<TypeRef>,
        cursor: ArgCursor,
        hint: String,
    ): GeneratedExpression {
        val lines = ArrayList<String>()
        val args = ArrayList<String>()
        for (index in types.indices) {
            val lifted = liftFlatExpression(types[index], cursor, "${hint}_$index")
            lines.addAll(lifted.lines)
            args.add(lifted.expression)
        }
        return GeneratedExpression(lines, tupleExpression(args))
    }

    private fun liftListRangeExpression(
        elementType: TypeRef,
        ptr: String,
        len: String,
        hint: String,
    ): GeneratedExpression {
        val resolved = resolveAlias(elementType)
        if (resolved.kind() == TypeRef.TypeKind.PRIMITIVE) {
            when (resolved.name()) {
                "s8" -> return GeneratedExpression(emptyList(), "krwaLoadByteArray($ptr, $len)")
                "u8" -> return GeneratedExpression(emptyList(), "krwaLoadUByteArray($ptr, $len)")
            }
        }
        val lines = ArrayList<String>()
        val result = localName("${hint}List")
        val index = localName("${hint}Index")
        val elementPtr = localName("${hint}ElementPtr")
        val stride = listStride(elementType)
        val listType = adapterListType(elementType)
        lines.add("val $result = ${emptyListExpression(listType, len)}")
        lines.add("var $index = 0")
        lines.add("while ($index < $len) {")
        lines.add("  val $elementPtr = $ptr + ($index * $stride)")
        val lifted = liftMemoryExpression(elementType, elementPtr, localName("${hint}Element"))
        for (line in lifted.lines) {
            lines.add("  $line")
        }
        lines.add("  ${listAddStatement(result, listType, index, lifted.expression)}")
        lines.add("  $index++")
        lines.add("}")
        return GeneratedExpression(lines, result)
    }

    private fun liftMemoryExpression(
        type: TypeRef,
        ptr: String,
        hint: String,
    ): GeneratedExpression {
        val resolved = resolveAlias(type)
        if (resolved.kind() == TypeRef.TypeKind.PRIMITIVE) {
            return liftPrimitiveMemoryExpression(resolved.name()!!, ptr)
        }
        if (resolved.kind() == TypeRef.TypeKind.NAMED) {
            val declaration = findTypeDeclaration(resolved.name()!!)
            if (declaration != null) {
                return liftNamedMemoryExpression(declaration, type, ptr, hint)
            }
        }
        return when (resolved.kind()) {
            TypeRef.TypeKind.LIST -> {
                val listPtr = "krwaLoadI32($ptr)"
                val listLen = "krwaLoadI32($ptr + 4)"
                liftListRangeExpression(firstArgument(resolved), listPtr, listLen, hint)
            }
            TypeRef.TypeKind.OPTION,
            TypeRef.TypeKind.RESULT -> liftConstructedVariantMemoryExpression(resolved, ptr, hint)
            TypeRef.TypeKind.TUPLE -> liftTupleMemoryExpression(resolved.arguments(), ptr, hint)
            TypeRef.TypeKind.FUTURE ->
                GeneratedExpression(
                    emptyList(),
                    "WitFuture.of<${adapterOptionalArgument(resolved.arguments())}>(krwaLoadI32($ptr).toLong())",
                )
            TypeRef.TypeKind.STREAM ->
                GeneratedExpression(
                    emptyList(),
                    "WitStream.of<${adapterOptionalArgument(resolved.arguments())}>(krwaLoadI32($ptr).toLong())",
                )
            TypeRef.TypeKind.BORROW,
            TypeRef.TypeKind.OWN ->
                GeneratedExpression(emptyList(), "krwaLoadI32($ptr).toLong()")
            else -> unsupportedGeneratedExpression(resolved)
        }
    }

    private fun liftPrimitiveMemoryExpression(name: String, ptr: String): GeneratedExpression =
        when (name) {
            "unit" -> GeneratedExpression(emptyList(), "Unit")
            "bool" -> GeneratedExpression(emptyList(), "krwaLoadI8($ptr).toInt() != 0")
            "s8" -> GeneratedExpression(emptyList(), "krwaLoadI8($ptr)")
            "u8" -> GeneratedExpression(emptyList(), "krwaLoadI8($ptr).toUByte()")
            "s16" -> GeneratedExpression(emptyList(), "krwaLoadI16($ptr)")
            "u16" -> GeneratedExpression(emptyList(), "krwaLoadI16($ptr).toUShort()")
            "s32",
            "char" -> GeneratedExpression(emptyList(), "krwaLoadI32($ptr)")
            "u32" -> GeneratedExpression(emptyList(), "krwaLoadI32($ptr).toUInt()")
            "s64" -> GeneratedExpression(emptyList(), "krwaLoadI64($ptr)")
            "u64" -> GeneratedExpression(emptyList(), "krwaLoadI64($ptr).toULong()")
            "f32" -> GeneratedExpression(emptyList(), "krwaLoadF32($ptr)")
            "f64" -> GeneratedExpression(emptyList(), "krwaLoadF64($ptr)")
            "string" -> GeneratedExpression(emptyList(), "krwaLoadString(krwaLoadI32($ptr), krwaLoadI32($ptr + 4))")
            else -> unsupportedGeneratedExpression(TypeRef.primitive(name))
        }

    private fun liftNamedMemoryExpression(
        declaration: TypeDeclaration,
        originalType: TypeRef,
        ptr: String,
        hint: String,
    ): GeneratedExpression =
        when (declaration.kind()) {
            TypeDeclaration.Kind.ALIAS -> liftMemoryExpression(declaration.target()!!, ptr, hint)
            TypeDeclaration.Kind.RESOURCE ->
                GeneratedExpression(emptyList(), "WitResource(krwaLoadI32($ptr).toUInt())")
            TypeDeclaration.Kind.RECORD ->
                liftRecordMemoryExpression(
                    adapterKotlinType(originalType),
                    declaration.fields(),
                    ptr,
                    hint,
                )
            TypeDeclaration.Kind.FLAGS ->
                liftFlagsMemoryExpression(adapterKotlinType(originalType), declaration.cases(), ptr)
            TypeDeclaration.Kind.ENUM ->
                GeneratedExpression(
                    emptyList(),
                    "${adapterKotlinType(originalType)}.entries[${loadDiscriminantExpression(ptr, declaration.cases().size)}]",
                )
            TypeDeclaration.Kind.VARIANT ->
                liftVariantMemoryExpression(
                    adapterKotlinType(originalType),
                    declarationCases(declaration),
                    ptr,
                    hint,
                )
        }

    private fun liftRecordMemoryExpression(
        typeName: String,
        fields: List<Field>,
        ptr: String,
        hint: String,
    ): GeneratedExpression {
        val lines = ArrayList<String>()
        val args = ArrayList<String>()
        var offset = 0
        for (index in fields.indices) {
            val field = fields[index]
            offset = alignTo(offset, canonicalAbi.alignment(field.type()))
            val lifted =
                liftMemoryExpression(field.type(), "$ptr + $offset", "${hint}_${memberName(field.name())}")
            lines.addAll(lifted.lines)
            args.add(memberName(field.name()) + " = " + lifted.expression)
            offset += canonicalAbi.elementSize(field.type())
        }
        return GeneratedExpression(lines, "$typeName(${args.joinToString(", ")})")
    }

    private fun liftTupleMemoryExpression(
        types: List<TypeRef>,
        ptr: String,
        hint: String,
    ): GeneratedExpression {
        val lines = ArrayList<String>()
        val args = ArrayList<String>()
        var offset = 0
        for (index in types.indices) {
            offset = alignTo(offset, canonicalAbi.alignment(types[index]))
            val lifted = liftMemoryExpression(types[index], "$ptr + $offset", "${hint}_$index")
            lines.addAll(lifted.lines)
            args.add(lifted.expression)
            offset += canonicalAbi.elementSize(types[index])
        }
        return GeneratedExpression(lines, tupleExpression(args))
    }

    private fun liftFlagsFlatExpression(
        typeName: String,
        flags: List<WitPackage.Case>,
        cursor: ArgCursor,
    ): GeneratedExpression {
        val words = ArrayList<String>()
        for (index in 0 until flagsWordCount(flags.size)) {
            words.add("arg${cursor.next++}")
        }
        return GeneratedExpression(emptyList(), flagsExpression(typeName, flags, words))
    }

    private fun liftFlagsMemoryExpression(
        typeName: String,
        flags: List<WitPackage.Case>,
        ptr: String,
    ): GeneratedExpression {
        val words =
            when (flagsSize(flags.size)) {
                1 -> listOf("krwaLoadI8($ptr).toInt()")
                2 -> listOf("krwaLoadI16($ptr).toInt()")
                4 -> listOf("krwaLoadI32($ptr)")
                else -> {
                    val result = ArrayList<String>()
                    for (index in 0 until flagsWordCount(flags.size)) {
                        result.add("krwaLoadI32($ptr + ${index * 4})")
                    }
                    result
                }
            }
        return GeneratedExpression(emptyList(), flagsExpression(typeName, flags, words))
    }

    private fun flagsExpression(
        typeName: String,
        flags: List<WitPackage.Case>,
        words: List<String>,
    ): String {
        val args = ArrayList<String>()
        for (index in flags.indices) {
            val word = words[index / 32]
            args.add(
                memberName(flags[index].name()) +
                    " = (($word ushr ${index % 32}) and 1) != 0"
            )
        }
        return "$typeName(${args.joinToString(", ")})"
    }

    private fun liftConstructedVariantFlatExpression(
        type: TypeRef,
        cursor: ArgCursor,
        hint: String,
    ): GeneratedExpression =
        liftVariantFlatExpression(adapterKotlinType(type), constructedCases(type), cursor, hint)

    private fun liftConstructedVariantMemoryExpression(
        type: TypeRef,
        ptr: String,
        hint: String,
    ): GeneratedExpression =
        liftVariantMemoryExpression(adapterKotlinType(type), constructedCases(type), ptr, hint)

    private fun liftVariantFlatExpression(
        typeName: String,
        cases: List<VariantCase>,
        cursor: ArgCursor,
        hint: String,
    ): GeneratedExpression {
        val discriminant = "arg${cursor.next++}"
        val payloadArgs = ArrayList<String>()
        val payloadTypes = variantPayloadFlatTypes(cases)
        for (index in payloadTypes.indices) {
            payloadArgs.add("arg${cursor.next++}")
        }
        val expression = localName("${hint}Variant")
        val lines = ArrayList<String>()
        lines.add("val $expression: $typeName = when ($discriminant) {")
        for (index in cases.indices) {
            val case = cases[index]
            val selected =
                liftVariantCaseFlatExpression(
                    typeName,
                    case,
                    payloadArgs,
                    payloadTypes,
                    localName("${hint}_${case.name}"),
                )
            appendWhenBranch(lines, index.toString(), selected)
        }
        lines.add("  else -> error(\"variant case index out of range: $$discriminant\")")
        lines.add("}")
        return GeneratedExpression(lines, expression)
    }

    private fun liftVariantCaseFlatExpression(
        typeName: String,
        case: VariantCase,
        payloadArgs: List<String>,
        payloadTypes: List<CoreValType>,
        hint: String,
    ): GeneratedExpression {
        if (case.type == null) {
            return GeneratedExpression(emptyList(), variantCaseExpression(typeName, case.name, null))
        }
        val cursor = ArgCursor()
        val lifted =
            liftFlatExpressionFromArgs(
                case.type,
                variantPayloadArgsForCase(case.type, payloadArgs, payloadTypes),
                cursor,
                hint,
            )
        return GeneratedExpression(lifted.lines, variantCaseExpression(typeName, case.name, lifted.expression))
    }

    private fun liftFlatExpressionFromArgs(
        type: TypeRef,
        args: List<String>,
        cursor: ArgCursor,
        hint: String,
    ): GeneratedExpression {
        val resolved = resolveAlias(type)
        if (resolved.kind() == TypeRef.TypeKind.PRIMITIVE) {
            return when (resolved.name()) {
                "unit" -> GeneratedExpression(emptyList(), "Unit")
                "string" -> {
                    val ptr = args[cursor.next++]
                    val len = args[cursor.next++]
                    GeneratedExpression(emptyList(), "krwaLoadString($ptr, $len)")
                }
                else -> {
                    val value = args[cursor.next++]
                    GeneratedExpression(emptyList(), coreToKotlin(value, TypeRef.primitive(resolved.name()!!)))
                }
            }
        }
        if (resolved.kind() == TypeRef.TypeKind.NAMED) {
            val declaration = findTypeDeclaration(resolved.name()!!)
            if (declaration != null) {
                return when (declaration.kind()) {
                    TypeDeclaration.Kind.ALIAS ->
                        liftFlatExpressionFromArgs(declaration.target()!!, args, cursor, hint)
                    TypeDeclaration.Kind.RESOURCE ->
                        GeneratedExpression(emptyList(), "WitResource(${args[cursor.next++]}.toUInt())")
                    TypeDeclaration.Kind.RECORD ->
                        liftRecordFlatExpressionFromArgs(
                            adapterKotlinType(type),
                            declaration.fields(),
                            args,
                            cursor,
                            hint,
                        )
                    TypeDeclaration.Kind.FLAGS ->
                        liftFlagsFlatExpressionFromArgs(adapterKotlinType(type), declaration.cases(), args, cursor)
                    TypeDeclaration.Kind.ENUM ->
                        GeneratedExpression(emptyList(), "${adapterKotlinType(type)}.entries[${args[cursor.next++]}]")
                    TypeDeclaration.Kind.VARIANT ->
                        liftVariantFlatExpressionFromArgs(
                            adapterKotlinType(type),
                            declarationCases(declaration),
                            args,
                            cursor,
                            hint,
                        )
                }
            }
        }
        return when (resolved.kind()) {
            TypeRef.TypeKind.LIST -> {
                val ptr = args[cursor.next++]
                val len = args[cursor.next++]
                liftListRangeExpression(firstArgument(resolved), ptr, len, hint)
            }
            TypeRef.TypeKind.OPTION,
            TypeRef.TypeKind.RESULT ->
                liftVariantFlatExpressionFromArgs(
                    adapterKotlinType(resolved),
                    constructedCases(resolved),
                    args,
                    cursor,
                    hint,
                )
            TypeRef.TypeKind.TUPLE ->
                liftTupleFlatExpressionFromArgs(resolved.arguments(), args, cursor, hint)
            TypeRef.TypeKind.FUTURE ->
                GeneratedExpression(
                    emptyList(),
                    "WitFuture.of<${adapterOptionalArgument(resolved.arguments())}>(${args[cursor.next++]}.toLong())",
                )
            TypeRef.TypeKind.STREAM ->
                GeneratedExpression(
                    emptyList(),
                    "WitStream.of<${adapterOptionalArgument(resolved.arguments())}>(${args[cursor.next++]}.toLong())",
                )
            TypeRef.TypeKind.BORROW,
            TypeRef.TypeKind.OWN -> GeneratedExpression(emptyList(), "${args[cursor.next++]}.toLong()")
            else -> unsupportedGeneratedExpression(resolved)
        }
    }

    private fun liftRecordFlatExpressionFromArgs(
        typeName: String,
        fields: List<Field>,
        args: List<String>,
        cursor: ArgCursor,
        hint: String,
    ): GeneratedExpression {
        val lines = ArrayList<String>()
        val values = ArrayList<String>()
        for (field in fields) {
            val lifted =
                liftFlatExpressionFromArgs(
                    field.type(),
                    args,
                    cursor,
                    "${hint}_${memberName(field.name())}",
                )
            lines.addAll(lifted.lines)
            values.add(memberName(field.name()) + " = " + lifted.expression)
        }
        return GeneratedExpression(lines, "$typeName(${values.joinToString(", ")})")
    }

    private fun liftTupleFlatExpressionFromArgs(
        types: List<TypeRef>,
        args: List<String>,
        cursor: ArgCursor,
        hint: String,
    ): GeneratedExpression {
        val lines = ArrayList<String>()
        val values = ArrayList<String>()
        for (index in types.indices) {
            val lifted = liftFlatExpressionFromArgs(types[index], args, cursor, "${hint}_$index")
            lines.addAll(lifted.lines)
            values.add(lifted.expression)
        }
        return GeneratedExpression(lines, tupleExpression(values))
    }

    private fun liftFlagsFlatExpressionFromArgs(
        typeName: String,
        flags: List<WitPackage.Case>,
        args: List<String>,
        cursor: ArgCursor,
    ): GeneratedExpression {
        val words = ArrayList<String>()
        for (index in 0 until flagsWordCount(flags.size)) {
            words.add(args[cursor.next++])
        }
        return GeneratedExpression(emptyList(), flagsExpression(typeName, flags, words))
    }

    private fun liftVariantFlatExpressionFromArgs(
        typeName: String,
        cases: List<VariantCase>,
        args: List<String>,
        cursor: ArgCursor,
        hint: String,
    ): GeneratedExpression {
        val discriminant = args[cursor.next++]
        val payloadArgs = ArrayList<String>()
        val payloadTypes = variantPayloadFlatTypes(cases)
        for (index in payloadTypes.indices) {
            payloadArgs.add(args[cursor.next++])
        }
        val expression = localName("${hint}Variant")
        val lines = ArrayList<String>()
        lines.add("val $expression: $typeName = when ($discriminant) {")
        for (index in cases.indices) {
            val selected =
                liftVariantCaseFlatExpression(
                    typeName,
                    cases[index],
                    payloadArgs,
                    payloadTypes,
                    localName("${hint}_${cases[index].name}"),
                )
            appendWhenBranch(lines, index.toString(), selected)
        }
        lines.add("  else -> error(\"variant case index out of range: $$discriminant\")")
        lines.add("}")
        return GeneratedExpression(lines, expression)
    }

    private fun liftVariantMemoryExpression(
        typeName: String,
        cases: List<VariantCase>,
        ptr: String,
        hint: String,
    ): GeneratedExpression {
        val discriminant = localName("${hint}Discriminant")
        val expression = localName("${hint}Variant")
        val lines = ArrayList<String>()
        lines.add("val $discriminant = ${loadDiscriminantExpression(ptr, cases.size)}")
        lines.add("val $expression: $typeName = when ($discriminant) {")
        val payloadPtr = variantPayloadPtrExpression(ptr, cases)
        for (index in cases.indices) {
            val case = cases[index]
            if (case.type == null) {
                lines.add("  $index -> ${variantCaseExpression(typeName, case.name, null)}")
            } else {
                val lifted =
                    liftMemoryExpression(case.type, payloadPtr, localName("${hint}_${case.name}"))
                appendWhenBranch(
                    lines,
                    index.toString(),
                    GeneratedExpression(
                        lifted.lines,
                        variantCaseExpression(typeName, case.name, lifted.expression),
                    ),
                )
            }
        }
        lines.add("  else -> error(\"variant case index out of range: $$discriminant\")")
        lines.add("}")
        return GeneratedExpression(lines, expression)
    }

    private fun variantCaseExpression(
        variantTypeName: String,
        caseName: String,
        payload: String?,
    ): String {
        if (variantTypeName.startsWith("WitResult<")) {
            return if (caseName == "ok") {
                "WitResult.Ok(${payload ?: "Unit"})"
            } else {
                "WitResult.Err(${payload ?: "Unit"})"
            }
        }
        if (variantTypeName.endsWith("?")) {
            return if (caseName == "none") "null" else payload ?: "Unit"
        }
        val nestedCase = variantTypeName + "." + typeName(caseName)
        return if (payload == null) nestedCase else "$nestedCase($payload)"
    }

    private fun tupleExpression(args: List<String>): String =
        when (args.size) {
            0 -> "Unit"
            1 -> "WitTuple1(${args[0]})"
            2 -> "Pair(${args[0]}, ${args[1]})"
            3 -> "Triple(${args[0]}, ${args[1]}, ${args[2]})"
            in 4..8 -> "WitTuple${args.size}(${args.joinToString(", ")})"
            else -> "listOf(${args.joinToString(", ")})"
        }

    private fun emptyListExpression(listType: String, size: String): String =
        when {
            listType == "ShortArray" -> "ShortArray($size)"
            listType == "IntArray" -> "IntArray($size)"
            listType == "LongArray" -> "LongArray($size)"
            listType == "UShortArray" -> "UShortArray($size)"
            listType == "UIntArray" -> "UIntArray($size)"
            listType == "ULongArray" -> "ULongArray($size)"
            listType == "FloatArray" -> "FloatArray($size)"
            listType == "DoubleArray" -> "DoubleArray($size)"
            listType.startsWith("List<") -> "ArrayList<${listType.removePrefix("List<").removeSuffix(">")}>()"
            else -> "ArrayList<Any?>()"
        }

    private fun listAddStatement(
        listName: String,
        listType: String,
        indexName: String,
        valueExpression: String,
    ): String =
        when (listType) {
            "ShortArray",
            "IntArray",
            "LongArray",
            "UShortArray",
            "UIntArray",
            "ULongArray",
            "FloatArray",
            "DoubleArray" -> "$listName[$indexName] = $valueExpression"
            else -> "$listName.add($valueExpression)"
        }

    private fun appendWhenBranch(
        lines: MutableList<String>,
        target: String,
        branch: GeneratedExpression,
    ) {
        if (branch.lines.isEmpty()) {
            lines.add("  $target -> ${branch.expression}")
            return
        }
        lines.add("  $target -> {")
        for (line in branch.lines) {
            lines.add("    $line")
        }
        lines.add("    ${branch.expression}")
        lines.add("  }")
    }

    private fun lowerFlatExpressions(
        value: String,
        type: TypeRef,
        hint: String,
    ): GeneratedFlat {
        val resolved = resolveAlias(type)
        if (resolved.kind() == TypeRef.TypeKind.PRIMITIVE) {
            return lowerPrimitiveFlatExpressions(value, resolved.name()!!, hint)
        }
        if (resolved.kind() == TypeRef.TypeKind.NAMED) {
            val declaration = findTypeDeclaration(resolved.name()!!)
            if (declaration != null) {
                return lowerNamedFlatExpressions(value, declaration, type, hint)
            }
        }
        return when (resolved.kind()) {
            TypeRef.TypeKind.LIST -> lowerListFlatExpressions(value, firstArgument(resolved), hint)
            TypeRef.TypeKind.OPTION,
            TypeRef.TypeKind.RESULT ->
                lowerVariantFlatExpressions(value, adapterKotlinType(resolved), constructedCases(resolved), hint)
            TypeRef.TypeKind.TUPLE -> lowerTupleFlatExpressions(value, resolved.arguments(), hint)
            TypeRef.TypeKind.FUTURE,
            TypeRef.TypeKind.STREAM -> GeneratedFlat(emptyList(), listOf("$value.handle().toInt()"))
            TypeRef.TypeKind.BORROW,
            TypeRef.TypeKind.OWN -> GeneratedFlat(emptyList(), listOf("$value.handle.toInt()"))
            else -> unsupportedGeneratedFlat(resolved)
        }
    }

    private fun lowerPrimitiveFlatExpressions(
        value: String,
        name: String,
        hint: String,
    ): GeneratedFlat =
        when (name) {
            "unit" -> GeneratedFlat(emptyList(), emptyList())
            "string" -> {
                val bytes = localName("${hint}Bytes")
                val ptr = localName("${hint}Ptr")
                GeneratedFlat(
                    listOf(
                        "val $bytes = $value.encodeToByteArray()",
                        "val $ptr = krwaStoreBytes($bytes)",
                    ),
                    listOf(ptr, "$bytes.size"),
                )
            }
            else -> GeneratedFlat(emptyList(), listOf(kotlinToCore(value, TypeRef.primitive(name))))
        }

    private fun lowerNamedFlatExpressions(
        value: String,
        declaration: TypeDeclaration,
        originalType: TypeRef,
        hint: String,
    ): GeneratedFlat =
        when (declaration.kind()) {
            TypeDeclaration.Kind.ALIAS ->
                lowerFlatExpressions(value, declaration.target()!!, hint)
            TypeDeclaration.Kind.RESOURCE ->
                GeneratedFlat(emptyList(), listOf("$value.handle.toInt()"))
            TypeDeclaration.Kind.RECORD ->
                lowerRecordFlatExpressions(value, declaration.fields(), hint)
            TypeDeclaration.Kind.FLAGS ->
                lowerFlagsFlatExpressions(value, declaration.cases())
            TypeDeclaration.Kind.ENUM ->
                GeneratedFlat(emptyList(), listOf("$value.ordinal"))
            TypeDeclaration.Kind.VARIANT ->
                lowerVariantFlatExpressions(value, adapterKotlinType(originalType), declarationCases(declaration), hint)
        }

    private fun lowerRecordFlatExpressions(
        value: String,
        fields: List<Field>,
        hint: String,
    ): GeneratedFlat {
        val lines = ArrayList<String>()
        val expressions = ArrayList<String>()
        for (field in fields) {
            val lowered =
                lowerFlatExpressions(
                    "$value.${memberName(field.name())}",
                    field.type(),
                    "${hint}_${memberName(field.name())}",
                )
            lines.addAll(lowered.lines)
            expressions.addAll(lowered.expressions)
        }
        return GeneratedFlat(lines, expressions)
    }

    private fun lowerTupleFlatExpressions(
        value: String,
        types: List<TypeRef>,
        hint: String,
    ): GeneratedFlat {
        val lines = ArrayList<String>()
        val expressions = ArrayList<String>()
        for (index in types.indices) {
            val lowered =
                lowerFlatExpressions("$value.${tupleAccessor(index)}", types[index], "${hint}_$index")
            lines.addAll(lowered.lines)
            expressions.addAll(lowered.expressions)
        }
        return GeneratedFlat(lines, expressions)
    }

    private fun lowerListFlatExpressions(
        value: String,
        elementType: TypeRef,
        hint: String,
    ): GeneratedFlat {
        val stored = storeListRangeLines(value, elementType, hint)
        return GeneratedFlat(stored.lines, listOf(stored.ptrExpression, stored.lengthExpression))
    }

    private fun lowerFlagsFlatExpressions(
        value: String,
        flags: List<WitPackage.Case>,
    ): GeneratedFlat {
        val words = ArrayList<String>()
        for (wordIndex in 0 until flagsWordCount(flags.size)) {
            val parts = ArrayList<String>()
            for (index in flags.indices) {
                if (index / 32 == wordIndex) {
                    parts.add(
                        "(if ($value.${memberName(flags[index].name())}) " +
                            "(1 shl ${index % 32}) else 0)"
                    )
                }
            }
            words.add(if (parts.isEmpty()) "0" else parts.joinToString(" or "))
        }
        return GeneratedFlat(emptyList(), words)
    }

    private fun lowerVariantFlatExpressions(
        value: String,
        typeName: String,
        cases: List<VariantCase>,
        hint: String,
    ): GeneratedFlat {
        val lines = ArrayList<String>()
        val result = localName("${hint}Flat")
        val subject = localName("${hint}Value")
        val payloadTypes = variantPayloadFlatTypes(cases)
        lines.add("val $subject = $value")
        lines.add("val $result: Array<Any?> = when ($subject) {")
        for (index in cases.indices) {
            val case = cases[index]
            val branch =
                lowerVariantFlatBranch(
                    subject,
                    typeName,
                    case,
                    index,
                    localName("${hint}_${case.name}"),
                    payloadTypes,
                )
            appendWhenBranch(lines, branch.target, GeneratedExpression(branch.lines, branch.expression))
        }
        lines.add("}")
        val expressions = ArrayList<String>()
        expressions.add("$result[0] as Int")
        for (index in payloadTypes.indices) {
            expressions.add("$result[${index + 1}] as ${coreKotlinType(payloadTypes[index].valType())}")
        }
        return GeneratedFlat(lines, expressions)
    }

    private fun lowerVariantFlatBranch(
        value: String,
        typeName: String,
        case: VariantCase,
        index: Int,
        hint: String,
        payloadTypes: List<CoreValType>,
    ): GeneratedBranch {
        val target = variantBranchTarget(value, typeName, case)
        val lines = ArrayList<String>()
        val expressions = ArrayList<String>()
        expressions.add(index.toString())
        if (case.type != null) {
            val payload = variantPayloadExpression(value, typeName, case)
            val lowered = lowerFlatExpressions(payload, case.type, localName("${hint}_${case.name}"))
            lines.addAll(lowered.lines)
            val caseTypes = canonicalAbi.flattenType(case.type)
            for (payloadIndex in lowered.expressions.indices) {
                expressions.add(
                    coerceFlatExpression(
                        lowered.expressions[payloadIndex],
                        caseTypes[payloadIndex],
                        payloadTypes[payloadIndex],
                    )
                )
            }
        }
        while (expressions.size < 1 + payloadTypes.size) {
            expressions.add(defaultFlatExpression(payloadTypes[expressions.size - 1]))
        }
        return GeneratedBranch(target, lines, "arrayOf<Any?>(${expressions.joinToString(", ")})")
    }

    private fun storeValueLines(
        value: String,
        type: TypeRef,
        ptr: String,
        hint: String,
    ): List<String> {
        val resolved = resolveAlias(type)
        if (resolved.kind() == TypeRef.TypeKind.PRIMITIVE) {
            return storePrimitiveLines(value, resolved.name()!!, ptr, hint)
        }
        if (resolved.kind() == TypeRef.TypeKind.NAMED) {
            val declaration = findTypeDeclaration(resolved.name()!!)
            if (declaration != null) {
                return storeNamedLines(value, declaration, type, ptr, hint)
            }
        }
        return when (resolved.kind()) {
            TypeRef.TypeKind.LIST -> storeListLines(value, firstArgument(resolved), ptr, hint)
            TypeRef.TypeKind.OPTION,
            TypeRef.TypeKind.RESULT ->
                storeVariantLines(value, adapterKotlinType(resolved), constructedCases(resolved), ptr, hint)
            TypeRef.TypeKind.TUPLE -> storeTupleLines(value, resolved.arguments(), ptr, hint)
            TypeRef.TypeKind.FUTURE,
            TypeRef.TypeKind.STREAM -> listOf("krwaStoreI32($ptr, $value.handle().toInt())")
            TypeRef.TypeKind.BORROW,
            TypeRef.TypeKind.OWN -> listOf("krwaStoreI32($ptr, $value.handle.toInt())")
            else -> listOf("error(\"unsupported WIT type in guest export adapter: $resolved\")")
        }
    }

    private fun storePrimitiveLines(
        value: String,
        name: String,
        ptr: String,
        hint: String,
    ): List<String> =
        when (name) {
            "unit" -> emptyList()
            "bool" -> listOf("krwaStoreI8($ptr, (if ($value) 1 else 0).toByte())")
            "s8" -> listOf("krwaStoreI8($ptr, $value)")
            "u8" -> listOf("krwaStoreI8($ptr, $value.toByte())")
            "s16" -> listOf("krwaStoreI16($ptr, $value)")
            "u16" -> listOf("krwaStoreI16($ptr, $value.toShort())")
            "s32",
            "char" -> listOf("krwaStoreI32($ptr, $value)")
            "u32" -> listOf("krwaStoreI32($ptr, $value.toInt())")
            "s64" -> listOf("krwaStoreI64($ptr, $value)")
            "u64" -> listOf("krwaStoreI64($ptr, $value.toLong())")
            "f32" -> listOf("krwaStoreF32($ptr, $value)")
            "f64" -> listOf("krwaStoreF64($ptr, $value)")
            "string" -> {
                listOf("krwaStoreString($ptr, $value)")
            }
            else -> listOf("error(\"unsupported primitive WIT type in guest export adapter: $name\")")
        }

    private fun storeNamedLines(
        value: String,
        declaration: TypeDeclaration,
        originalType: TypeRef,
        ptr: String,
        hint: String,
    ): List<String> =
        when (declaration.kind()) {
            TypeDeclaration.Kind.ALIAS -> storeValueLines(value, declaration.target()!!, ptr, hint)
            TypeDeclaration.Kind.RESOURCE -> listOf("krwaStoreI32($ptr, $value.handle.toInt())")
            TypeDeclaration.Kind.RECORD ->
                guestExportStoreHelpers[declaration]?.let { helper ->
                    listOf("${helper.storeFunctionName}($ptr, $value)")
                } ?: storeRecordLines(value, declaration.fields(), ptr, hint)
            TypeDeclaration.Kind.FLAGS -> storeFlagsLines(value, declaration.cases(), ptr)
            TypeDeclaration.Kind.ENUM ->
                listOf(storeDiscriminantStatement(ptr, "$value.ordinal", declaration.cases().size))
            TypeDeclaration.Kind.VARIANT ->
                storeVariantLines(value, adapterKotlinType(originalType), declarationCases(declaration), ptr, hint)
        }

    private fun storeRecordLines(
        value: String,
        fields: List<Field>,
        ptr: String,
        hint: String,
    ): List<String> {
        val lines = ArrayList<String>()
        var offset = 0
        for (field in fields) {
            offset = alignTo(offset, canonicalAbi.alignment(field.type()))
            lines.addAll(
                storeValueLines(
                    "$value.${memberName(field.name())}",
                    field.type(),
                    "$ptr + $offset",
                    "${hint}_${memberName(field.name())}",
                )
            )
            offset += canonicalAbi.elementSize(field.type())
        }
        return lines
    }

    private fun storeTupleLines(
        value: String,
        types: List<TypeRef>,
        ptr: String,
        hint: String,
    ): List<String> {
        val lines = ArrayList<String>()
        var offset = 0
        for (index in types.indices) {
            offset = alignTo(offset, canonicalAbi.alignment(types[index]))
            lines.addAll(
                storeValueLines(
                    "$value.${tupleAccessor(index)}",
                    types[index],
                    "$ptr + $offset",
                    "${hint}_$index",
                )
            )
            offset += canonicalAbi.elementSize(types[index])
        }
        return lines
    }

    private fun storeListLines(
        value: String,
        elementType: TypeRef,
        ptr: String,
        hint: String,
    ): List<String> {
        val stored = storeListRangeLines(value, elementType, hint)
        val lines = ArrayList<String>()
        lines.addAll(stored.lines)
        lines.add("krwaStoreI32($ptr, ${stored.ptrExpression})")
        lines.add("krwaStoreI32($ptr + 4, ${stored.lengthExpression})")
        return lines
    }

    private fun storeListRangeLines(
        value: String,
        elementType: TypeRef,
        hint: String,
    ): StoredRange {
        val resolved = resolveAlias(elementType)
        if (resolved.kind() == TypeRef.TypeKind.PRIMITIVE && resolved.name() == "string") {
            val ptr = localName("${hint}Ptr")
            return StoredRange(listOf("val $ptr = krwaStoreStringList($value)"), ptr, "$value.size")
        }
        recordStoreHelperForType(resolved)?.let { helper ->
            val ptr = localName("${hint}Ptr")
            return StoredRange(listOf("val $ptr = ${helper.storeListFunctionName}($value)"), ptr, "$value.size")
        }
        if (resolved.kind() == TypeRef.TypeKind.PRIMITIVE && resolved.name() == "s8") {
            val ptr = localName("${hint}Ptr")
            return StoredRange(listOf("val $ptr = krwaStoreBytes($value)"), ptr, "$value.size")
        }
        if (resolved.kind() == TypeRef.TypeKind.PRIMITIVE && resolved.name() == "u8") {
            val bytes = localName("${hint}Bytes")
            val ptr = localName("${hint}Ptr")
            val index = localName("${hint}ByteIndex")
            return StoredRange(
                listOf(
                    "val $bytes = ByteArray($value.size)",
                    "var $index = 0",
                    "while ($index < $value.size) {",
                    "  $bytes[$index] = $value[$index].toByte()",
                    "  $index++",
                    "}",
                    "val $ptr = krwaStoreBytes($bytes)",
                ),
                ptr,
                "$value.size",
            )
        }

        val lines = ArrayList<String>()
        val length = localName("${hint}Length")
        val ptr = localName("${hint}Ptr")
        val index = localName("${hint}Index")
        val elementPtr = localName("${hint}ElementPtr")
        val stride = listStride(elementType)
        lines.add("val $length = $value.size")
        lines.add("val $ptr = krwaAlloc($stride * $length)")
        lines.add("var $index = 0")
        lines.add("while ($index < $length) {")
        lines.add("  val $elementPtr = $ptr + ($index * $stride)")
        val elementExpression = "$value[$index]"
        for (line in storeValueLines(elementExpression, elementType, elementPtr, localName("${hint}Element"))) {
            lines.add("  $line")
        }
        lines.add("  $index++")
        lines.add("}")
        return StoredRange(lines, ptr, length)
    }

    private fun storeFlagsLines(
        value: String,
        flags: List<WitPackage.Case>,
        ptr: String,
    ): List<String> {
        val flat = lowerFlagsFlatExpressions(value, flags).expressions
        return when (flagsSize(flags.size)) {
            1 -> listOf("krwaStoreI8($ptr, (${flat[0]}).toByte())")
            2 -> listOf("krwaStoreI16($ptr, (${flat[0]}).toShort())")
            4 -> listOf("krwaStoreI32($ptr, ${flat[0]})")
            else -> {
                val lines = ArrayList<String>()
                for (index in flat.indices) {
                    lines.add("krwaStoreI32($ptr + ${index * 4}, ${flat[index]})")
                }
                lines
            }
        }
    }

    private fun storeVariantLines(
        value: String,
        typeName: String,
        cases: List<VariantCase>,
        ptr: String,
        hint: String,
    ): List<String> {
        if (typeName.endsWith("?") && cases.size == 2 && cases[0].name == "none") {
            val someType = cases[1].type
            if (someType != null) {
                val resolvedSomeType = resolveAlias(someType)
                if (resolvedSomeType.kind() == TypeRef.TypeKind.PRIMITIVE) {
                    when (resolvedSomeType.name()) {
                        "string" -> return listOf("krwaStoreOptionString($ptr, $value)")
                        "s32",
                        "u32" -> return listOf("krwaStoreOptionInt($ptr, $value)")
                    }
                }
            }
        }
        val lines = ArrayList<String>()
        val subject = localName("${hint}Value")
        lines.add("val $subject = $value")
        lines.add("when ($subject) {")
        for (index in cases.indices) {
            val case = cases[index]
            val target = variantBranchTarget(subject, typeName, case)
            lines.add("  $target -> {")
            lines.add("    ${storeDiscriminantStatement(ptr, index.toString(), cases.size)}")
            if (case.type != null) {
                val payload = variantPayloadExpression(subject, typeName, case)
                val payloadPtr = variantPayloadPtrExpression(ptr, cases)
                for (
                    line in
                        storeValueLines(
                            payload,
                            case.type,
                            payloadPtr,
                            localName("${hint}_${case.name}"),
                        )
                ) {
                    lines.add("    $line")
                }
            }
            lines.add("  }")
        }
        lines.add("}")
        return lines
    }

    private fun variantBranchTarget(value: String, variantTypeName: String, case: VariantCase): String {
        if (variantTypeName.startsWith("WitResult<")) {
            return if (case.name == "ok") {
                "is WitResult.Ok"
            } else {
                "is WitResult.Err"
            }
        }
        if (variantTypeName.endsWith("?")) {
            return if (case.name == "none") "null" else "else"
        }
        return if (case.type == null) {
            variantTypeName + "." + typeName(case.name)
        } else {
            "is " + variantTypeName + "." + typeName(case.name)
        }
    }

    private fun variantPayloadExpression(
        value: String,
        variantTypeName: String,
        case: VariantCase,
    ): String {
        if (variantTypeName.startsWith("WitResult<")) {
            return "$value.value"
        }
        if (variantTypeName.endsWith("?")) {
            return value
        }
        return "$value.value"
    }

    private fun declarationCases(declaration: TypeDeclaration): List<VariantCase> {
        val cases = ArrayList<VariantCase>()
        for (case in declaration.cases()) {
            cases.add(VariantCase(case.name(), unitToNull(case.type())))
        }
        return cases
    }

    private fun constructedCases(type: TypeRef): List<VariantCase> {
        val args = type.arguments()
        val cases = ArrayList<VariantCase>()
        when (type.kind()) {
            TypeRef.TypeKind.OPTION -> {
                cases.add(VariantCase("none", null))
                cases.add(VariantCase("some", if (args.isEmpty()) null else unitToNull(args[0])))
            }
            TypeRef.TypeKind.RESULT -> {
                cases.add(VariantCase("ok", if (args.isNotEmpty()) unitToNull(args[0]) else null))
                cases.add(VariantCase("err", if (args.size > 1) unitToNull(args[1]) else null))
            }
            else -> throw IllegalArgumentException("unsupported variant-like type $type")
        }
        return cases
    }

    private fun unitToNull(type: TypeRef?): TypeRef? {
        if (type == null) {
            return null
        }
        val resolved = resolveAlias(type)
        if (resolved.kind() == TypeRef.TypeKind.PRIMITIVE && resolved.name() == "unit") {
            return null
        }
        return type
    }

    private fun variantPayloadFlatTypes(cases: List<VariantCase>): List<CoreValType> {
        var result: List<CoreValType> = emptyList()
        for (case in cases) {
            if (case.type != null) {
                result = joinFlatTypes(result, canonicalAbi.flattenType(case.type))
            }
        }
        return result
    }

    private fun joinFlatTypes(left: List<CoreValType>, right: List<CoreValType>): List<CoreValType> {
        val result = ArrayList<CoreValType>()
        val size = maxOf(left.size, right.size)
        for (index in 0 until size) {
            val l = if (index < left.size) left[index] else null
            val r = if (index < right.size) right[index] else null
            result.add(joinFlatType(l, r))
        }
        return result
    }

    private fun joinFlatType(left: CoreValType?, right: CoreValType?): CoreValType {
        if (left == null) {
            return requireNotNull(right)
        }
        if (right == null || left == right) {
            return left
        }
        if (left == CoreValType.I64 || right == CoreValType.I64) {
            return CoreValType.I64
        }
        if (left == CoreValType.F64 || right == CoreValType.F64) {
            return CoreValType.I64
        }
        return CoreValType.I32
    }

    private fun variantPayloadArgsForCase(
        type: TypeRef,
        payloadArgs: List<String>,
        payloadTypes: List<CoreValType>,
    ): List<String> {
        val caseTypes = canonicalAbi.flattenType(type)
        val result = ArrayList<String>()
        for (index in caseTypes.indices) {
            result.add(coerceFlatArgument(payloadArgs[index], payloadTypes[index], caseTypes[index]))
        }
        return result
    }

    private fun coerceFlatArgument(
        value: String,
        from: CoreValType,
        to: CoreValType,
    ): String {
        if (from == to) {
            return value
        }
        return when (to) {
            CoreValType.I32 -> "($value).toInt()"
            CoreValType.I64 -> "($value).toLong()"
            CoreValType.F32 -> "Float.fromBits(($value).toInt())"
            CoreValType.F64 -> "Double.fromBits(($value).toLong())"
        }
    }

    private fun coerceFlatExpression(
        value: String,
        from: CoreValType,
        to: CoreValType,
    ): String {
        if (from == to) {
            return value
        }
        return when (to) {
            CoreValType.I32 ->
                if (from == CoreValType.F32) "($value).toBits()" else "($value).toInt()"
            CoreValType.I64 ->
                when (from) {
                    CoreValType.F32 -> "(($value).toBits().toLong() and 0xffffffffL)"
                    CoreValType.F64 -> "($value).toBits()"
                    else -> "($value).toLong()"
                }
            CoreValType.F32 ->
                if (from == CoreValType.I32) "Float.fromBits($value)" else value
            CoreValType.F64 ->
                if (from == CoreValType.I64) "Double.fromBits($value)" else value
        }
    }

    private fun defaultFlatExpression(type: CoreValType): String =
        when (type) {
            CoreValType.I32 -> "0"
            CoreValType.I64 -> "0L"
            CoreValType.F32 -> "0.0f"
            CoreValType.F64 -> "0.0"
        }

    private fun variantPayloadPtrExpression(ptr: String, cases: List<VariantCase>): String {
        var payloadAlignment = 1
        for (case in cases) {
            if (case.type != null) {
                payloadAlignment = maxOf(payloadAlignment, canonicalAbi.alignment(case.type))
            }
        }
        val base = "$ptr + ${discriminantSize(cases.size)}"
        return if (payloadAlignment <= 1) base else "krwaAlignTo($base, $payloadAlignment)"
    }

    private fun loadDiscriminantExpression(ptr: String, caseCount: Int): String =
        when (discriminantSize(caseCount)) {
            1 -> "krwaLoadI8($ptr).toInt()"
            2 -> "krwaLoadI16($ptr).toInt()"
            else -> "krwaLoadI32($ptr)"
        }

    private fun storeDiscriminantStatement(ptr: String, value: String, caseCount: Int): String =
        when (discriminantSize(caseCount)) {
            1 -> "krwaStoreI8($ptr, ($value).toByte())"
            2 -> "krwaStoreI16($ptr, ($value).toShort())"
            else -> "krwaStoreI32($ptr, $value)"
        }

    private fun firstArgument(type: TypeRef): TypeRef =
        if (type.arguments().isEmpty()) TypeRef.primitive("unit") else type.arguments()[0]

    private fun listStride(elementType: TypeRef): Int =
        alignTo(canonicalAbi.elementSize(elementType), canonicalAbi.alignment(elementType))

    private fun flagsWordCount(count: Int): Int = maxOf(1, (count + 31) / 32)

    private fun flagsSize(count: Int): Int {
        if (count <= 8) {
            return 1
        }
        if (count <= 16) {
            return 2
        }
        if (count <= 32) {
            return 4
        }
        return flagsWordCount(count) * 4
    }

    private fun discriminantSize(cases: Int): Int {
        if (cases <= 256) {
            return 1
        }
        if (cases <= 65536) {
            return 2
        }
        return 4
    }

    private fun unsupportedGeneratedExpression(type: TypeRef): GeneratedExpression =
        GeneratedExpression(
            emptyList(),
            "error(${kotlinString("unsupported WIT type in guest export adapter: $type")})",
        )

    private fun unsupportedGeneratedFlat(type: TypeRef): GeneratedFlat =
        GeneratedFlat(
            emptyList(),
            listOf("error(${kotlinString("unsupported WIT type in guest export adapter: $type")})"),
        )

    private data class GeneratedExpression(val lines: List<String>, val expression: String)

    private data class GeneratedBranch(
        val target: String,
        val lines: List<String>,
        val expression: String,
    )

    private data class GeneratedFlat(val lines: List<String>, val expressions: List<String>)

    private data class GeneratedParameters(val lines: List<String>, val arguments: List<String>)

    private data class StoredRange(
        val lines: List<String>,
        val ptrExpression: String,
        val lengthExpression: String,
    )

    private data class GuestExportStoreHelper(
        val storeFunctionName: String,
        val storeListFunctionName: String,
    )

    private data class VariantCase(val name: String, val type: TypeRef?)

    private class ArgCursor(var next: Int = 0)

    private fun coreToKotlin(value: String, type: TypeRef): String {
        val resolved = resolveAlias(type)
        if (resolved.kind() == TypeRef.TypeKind.NAMED) {
            val declaration = findTypeDeclaration(resolved.name()!!)
            if (declaration != null && declaration.kind() == TypeDeclaration.Kind.RESOURCE) {
                return "WitResource($value.toUInt())"
            }
        }
        if (resolved.kind() != TypeRef.TypeKind.PRIMITIVE) {
            return "$value.toLong()"
        }
        return when (resolved.name()) {
            "bool" -> "$value != 0"
            "s8" -> "$value.toByte()"
            "s16" -> "$value.toShort()"
            "s32",
            "char" -> value
            "s64" -> value
            "u8" -> "$value.toUByte()"
            "u16" -> "$value.toUShort()"
            "u32" -> "$value.toUInt()"
            "u64" -> "$value.toULong()"
            "f32",
            "f64" -> value
            else -> value
        }
    }

    private fun kotlinToCore(value: String, type: TypeRef): String {
        val resolved = resolveAlias(type)
        if (resolved.kind() == TypeRef.TypeKind.NAMED) {
            val declaration = findTypeDeclaration(resolved.name()!!)
            if (declaration != null && declaration.kind() == TypeDeclaration.Kind.RESOURCE) {
                return "$value.handle.toInt()"
            }
        }
        if (resolved.kind() != TypeRef.TypeKind.PRIMITIVE) {
            return "$value.handle().toInt()"
        }
        return when (resolved.name()) {
            "bool" -> "if ($value) 1 else 0"
            "s8",
            "s16",
            "s32",
            "char" -> value
            "s64" -> value
            "u8",
            "u16",
            "u32" -> "$value.toInt()"
            "u64" -> "$value.toLong()"
            "f32",
            "f64" -> value
            else -> value
        }
    }

    private fun guestExportBindings(): List<GuestExportBinding> {
        val result = ArrayList<GuestExportBinding>()
        for (world in witPackage.worlds()) {
            for (item in world.exports()) {
                if (item.isFunction) {
                    val function = item.function()!!
                    result.add(
                        GuestExportBinding(
                            world,
                            "",
                            function,
                            guestExportNames(world.name(), world.qualifiedName(), function.name(), function),
                            rootGuestAsyncExport(function),
                            world.name() + "." + function.name(),
                        )
                    )
                    continue
                }
                val declaration = findInterfaceForWorldItem(item)
                val receiver = "." + memberName(worldItemMemberName(item, world.exports()))
                for (member in declaration.members()) {
                    if (member is Function) {
                        val localName = interfaceName(item)
                        val names =
                            guestExportNames(
                                localName,
                                declaration.qualifiedName(),
                                member.name(),
                                member,
                                item.name(),
                            )
                        result.add(
                            GuestExportBinding(
                                world,
                                receiver,
                                member,
                                names,
                                interfaceGuestAsyncExport(declaration.qualifiedName(), member),
                                item.name() + "." + member.name(),
                            )
                        )
                    }
                }
            }
        }
        return result
    }

    private fun guestExportNames(
        interfaceName: String,
        qualifiedInterfaceName: String,
        functionName: String,
        function: Function,
        vararg additionalInterfaceNames: String,
    ): List<String> {
        val names = LinkedHashSet<String>()
        addGuestExportName(names, functionName, function)
        addGuestInterfaceExportNames(names, interfaceName, functionName, function)
        if (qualifiedInterfaceName != interfaceName) {
            addGuestInterfaceExportNames(names, qualifiedInterfaceName, functionName, function)
        }
        for (additionalInterfaceName in additionalInterfaceNames) {
            if (
                additionalInterfaceName != interfaceName &&
                    additionalInterfaceName != qualifiedInterfaceName
            ) {
                addGuestInterfaceExportNames(names, additionalInterfaceName, functionName, function)
            }
        }
        return ArrayList(names)
    }

    private fun addGuestInterfaceExportNames(
        names: MutableSet<String>,
        interfaceName: String,
        functionName: String,
        function: Function,
    ) {
        addGuestExportName(names, "$interfaceName.$functionName", function)
        addGuestExportName(names, "$interfaceName#$functionName", function)
        addGuestExportName(names, "$interfaceName/$functionName", function)
    }

    private fun addGuestExportName(names: MutableSet<String>, name: String, function: Function) {
        names.add(name)
        if (function.isAsync) {
            val asyncName = asyncGuestExportName(name)
            names.add(asyncName)
            if (asyncName != "[async]$name") {
                names.add("[async]$name")
            }
        }
    }

    private fun asyncGuestExportName(name: String): String {
        val separator = maxOf(name.lastIndexOf('#'), name.lastIndexOf('.'), name.lastIndexOf('/'))
        if (separator < 0) {
            return "[async]$name"
        }
        return name.substring(0, separator + 1) + "[async]" + name.substring(separator + 1)
    }

    private fun rootGuestAsyncExport(function: Function): GuestAsyncExport {
        val functionName = function.name()
        return guestAsyncExport(functionName, "[export]${'$'}root", "[task-return]$functionName")
    }

    private fun interfaceGuestAsyncExport(
        qualifiedInterfaceName: String,
        function: Function,
    ): GuestAsyncExport {
        val functionName = function.name()
        return guestAsyncExport(
            "$qualifiedInterfaceName#$functionName",
            "[export]$qualifiedInterfaceName",
            "[task-return]$functionName",
        )
    }

    private fun guestAsyncExport(
        exportName: String,
        taskReturnModule: String,
        taskReturnName: String,
    ): GuestAsyncExport =
        GuestAsyncExport(
            "[async-lift]$exportName",
            "[callback][async-lift]$exportName",
            GuestTaskReturn(taskReturnModule, taskReturnName),
        )

    private fun findInterfaceForWorldItem(item: WorldItem): InterfaceDeclaration =
        findInterface(item.type()?.name() ?: item.name())
            ?: findInterface(item.name())
            ?: throw IllegalArgumentException("unknown WIT interface ${item.name()}")

    private fun interfaceName(item: WorldItem): String {
        val type = item.type()
        val typeName = type?.name()
        if (type != null && type.kind() == TypeRef.TypeKind.NAMED && typeName != null) {
            return WitNames.lastSegment(typeName)
        }
        return WitNames.lastSegment(item.name())
    }

    private fun findTypeDeclaration(name: String): TypeDeclaration? {
        val normalized = normalizeTypeReference(name)
        if (isQualifiedTypeReference(name) || isQualifiedTypeReference(normalized)) {
            val simpleName = WitNames.lastSegment(normalized)
            for (declaration in witPackage.declarations()) {
                val found =
                    findQualifiedTypeDeclaration(
                        declaration,
                        name,
                        normalized,
                        simpleName,
                    )
                if (found != null) {
                    return found
                }
            }
            return null
        }
        val simpleName = WitNames.lastSegment(normalized)
        for (declaration in witPackage.declarations()) {
            val found = findTypeDeclaration(declaration, simpleName, name)
            if (found != null) {
                return found
            }
        }
        return null
    }

    private fun findQualifiedTypeDeclaration(
        declaration: Declaration,
        original: String,
        normalized: String,
        simpleName: String,
    ): TypeDeclaration? {
        if (declaration is TypeDeclaration) {
            return if (typeMatches(declaration.name(), original, normalized, simpleName)) {
                declaration
            } else {
                null
            }
        }
        if (declaration is InterfaceDeclaration) {
            for (member in declaration.members()) {
                if (
                    member is TypeDeclaration &&
                        (
                            typeMatches(
                                qualifiedTypeName(declaration.qualifiedName(), member.name()),
                                original,
                                normalized,
                                simpleName,
                            ) ||
                                typeMatches(
                                    declaration.qualifiedName() + "." + member.name(),
                                    original,
                                    normalized,
                                    simpleName,
                                )
                        )
                ) {
                    return member
                }
            }
        } else if (declaration is WorldDeclaration) {
            for (member in declaration.declarations()) {
                if (
                    member is TypeDeclaration &&
                        (
                            typeMatches(
                                qualifiedTypeName(declaration.qualifiedName(), member.name()),
                                original,
                                normalized,
                                simpleName,
                            ) ||
                                typeMatches(
                                    declaration.qualifiedName() + "." + member.name(),
                                    original,
                                    normalized,
                                    simpleName,
                                )
                        )
                ) {
                    return member
                }
            }
        }
        return null
    }

    private fun findTypeDeclaration(
        declaration: Declaration,
        normalized: String,
        original: String,
    ): TypeDeclaration? {
        if (declaration is TypeDeclaration) {
            if (declaration.name() == normalized || declaration.name() == original) {
                return declaration
            }
        } else if (declaration is InterfaceDeclaration) {
            for (member in declaration.members()) {
                if (member is TypeDeclaration) {
                    if (member.name() == normalized || member.name() == original) {
                        return member
                    }
                }
            }
        } else if (declaration is WorldDeclaration) {
            for (member in declaration.declarations()) {
                if (member is TypeDeclaration) {
                    if (member.name() == normalized || member.name() == original) {
                        return member
                    }
                }
            }
        }
        return null
    }

    private fun allTypeDeclarations(): List<TypeDeclaration> {
        val result = ArrayList<TypeDeclaration>()
        for (declaration in witPackage.declarations()) {
            collectTypeDeclarations(declaration, result)
        }
        return result
    }

    private fun collectTypeDeclarations(
        declaration: Declaration,
        result: MutableList<TypeDeclaration>,
    ) {
        when (declaration) {
            is TypeDeclaration -> result.add(declaration)
            is InterfaceDeclaration -> {
                for (member in declaration.members()) {
                    if (member is TypeDeclaration) {
                        result.add(member)
                    }
                }
            }
            is WorldDeclaration -> {
                for (member in declaration.declarations()) {
                    collectTypeDeclarations(member, result)
                }
            }
        }
    }

    private fun guestExportStoreHelpers(): Map<TypeDeclaration, GuestExportStoreHelper> {
        val usedNames = LinkedHashMap<String, Int>()
        val result = LinkedHashMap<TypeDeclaration, GuestExportStoreHelper>()
        for (declaration in allTypeDeclarations()) {
            if (declaration.kind() != TypeDeclaration.Kind.RECORD) {
                continue
            }
            result[declaration] =
                GuestExportStoreHelper(
                    uniqueGeneratedFunctionName("__krwa_store_${declaration.name()}", usedNames),
                    uniqueGeneratedFunctionName("__krwa_store_${declaration.name()}_list", usedNames),
                )
        }
        return result
    }

    private fun recordStoreHelperForType(type: TypeRef): GuestExportStoreHelper? {
        val resolved = resolveAlias(type)
        if (resolved.kind() != TypeRef.TypeKind.NAMED) {
            return null
        }
        val declaration = findTypeDeclaration(resolved.name()!!) ?: return null
        if (declaration.kind() != TypeDeclaration.Kind.RECORD) {
            return null
        }
        return guestExportStoreHelpers[declaration]
    }

    private fun resolveAlias(type: TypeRef): TypeRef {
        if (type.kind() == TypeRef.TypeKind.NAMED) {
            val declaration = findTypeDeclaration(type.name()!!)
            if (declaration != null && declaration.kind() == TypeDeclaration.Kind.ALIAS) {
                return resolveAlias(declaration.target()!!)
            }
        }
        return type
    }

    private fun uniqueGuestExportFunctionName(
        exportName: String,
        usedNames: MutableMap<String, Int>,
    ): String = uniqueGeneratedFunctionName("__krwa_export_$exportName", usedNames)

    private fun uniqueGeneratedFunctionName(
        sourceName: String,
        usedNames: MutableMap<String, Int>,
    ): String {
        val base = memberName(sourceName)
        val count = usedNames.getOrDefault(base, 0)
        usedNames[base] = count + 1
        return if (count == 0) base else base + (count + 1)
    }

    private fun coreKotlinType(type: ValType): String =
        when (type.name()) {
            "I32" -> "Int"
            "I64" -> "Long"
            "F32" -> "Float"
            "F64" -> "Double"
            else -> throw IllegalArgumentException("unsupported core Wasm value type $type")
        }

    private data class GuestExportBinding(
        val world: WorldDeclaration,
        val receiverPath: String,
        val function: Function,
        val exportNames: List<String>,
        val asyncExport: GuestAsyncExport,
        val debugName: String,
    )

    private data class GuestAsyncExport(
        val exportName: String,
        val callbackExportName: String,
        val taskReturn: GuestTaskReturn,
    )

    private data class GuestTaskReturn(val module: String, val name: String)

    class Builder internal constructor(internal val witPackage: WitPackage) {
        internal var witSource: String? = null
        internal var packageName: String? = "uk.shusek.krwa.generated"
        internal var runtimePackageName: String? = "uk.shusek.krwa.component"
        internal var includeRuntimeTypes: Boolean = false
        internal var includePluginHelpers: Boolean = false
        internal var includeGuestExportAdapters: Boolean = false

        fun withPackageName(packageName: String?): Builder {
            this.packageName = requireValidPackageName(packageName)
            return this
        }

        fun withWitSource(witSource: String?): Builder {
            this.witSource = witSource
            return this
        }

        fun withRuntimePackageName(runtimePackageName: String?): Builder {
            this.runtimePackageName = runtimePackageName
            return this
        }

        fun withRuntimeTypes(includeRuntimeTypes: Boolean): Builder {
            this.includeRuntimeTypes = includeRuntimeTypes
            return this
        }

        fun withPluginHelpers(includePluginHelpers: Boolean): Builder {
            this.includePluginHelpers = includePluginHelpers
            return this
        }

        fun withGuestExportAdapters(includeGuestExportAdapters: Boolean): Builder {
            this.includeGuestExportAdapters = includeGuestExportAdapters
            return this
        }

        fun build(): KotlinWitBindings = KotlinWitBindings(this)
    }

    companion object {
        private val KEYWORDS =
            setOf(
                "as",
                "break",
                "class",
                "constructor",
                "continue",
                "do",
                "else",
                "false",
                "for",
                "fun",
                "if",
                "in",
                "interface",
                "is",
                "null",
                "object",
                "package",
                "return",
                "super",
                "this",
                "throw",
                "true",
                "try",
                "typealias",
                "val",
                "var",
                "when",
                "while",
            )
        private val KOTLIN_PACKAGE_KEYWORDS = KEYWORDS - "constructor" + "typeof"

        @JvmStatic fun builder(witPackage: WitPackage): Builder = Builder(witPackage)

        private fun requireValidPackageName(packageName: String?): String? {
            if (packageName == null) {
                return null
            }
            require(packageName.isNotBlank()) {
                "packageName must be null or a non-empty Kotlin package name"
            }
            require(
                packageName.split('.').all { segment ->
                    isKotlinPackageSegment(segment) && segment !in KOTLIN_PACKAGE_KEYWORDS
                }
            ) {
                "packageName must contain only valid, non-keyword Kotlin identifier segments"
            }
            return packageName
        }

        private fun isKotlinPackageSegment(segment: String): Boolean {
            if (segment.isEmpty()) {
                return false
            }
            var offset = 0
            var codePoint = segment.codePointAt(offset)
            if (codePoint != '_'.code && !Character.isLetter(codePoint)) {
                return false
            }
            offset += Character.charCount(codePoint)
            while (offset < segment.length) {
                codePoint = segment.codePointAt(offset)
                if (
                    codePoint != '_'.code &&
                        !Character.isLetter(codePoint) &&
                        !Character.isDigit(codePoint)
                ) {
                    return false
                }
                offset += Character.charCount(codePoint)
            }
            return true
        }

        @JvmStatic
        fun generate(witPackage: WitPackage, packageName: String?): String =
            builder(witPackage).withPackageName(packageName).build().generate()

        @JvmStatic
        fun generate(witFileOrComponent: Path, packageName: String?): String =
            generate(Wit.parse(witFileOrComponent), packageName)

        @JvmStatic
        fun write(witPackage: WitPackage, packageName: String?, outputFile: Path): Path =
            builder(witPackage).withPackageName(packageName).build().writeTo(outputFile)

        @JvmStatic
        fun write(witFileOrComponent: Path, packageName: String?, outputFile: Path): Path =
            builder(Wit.parse(witFileOrComponent))
                .withPackageName(packageName)
                .build()
                .writeTo(outputFile)

        @JvmStatic
        fun writeDirectory(
            witPackage: WitPackage,
            packageName: String?,
            outputDirectory: Path,
        ): List<Path> =
            builder(witPackage).withPackageName(packageName).build().writeToDirectory(outputDirectory)

        @JvmStatic
        fun writeDirectory(
            witFileOrComponent: Path,
            packageName: String?,
            outputDirectory: Path,
        ): List<Path> =
            builder(Wit.parse(witFileOrComponent))
                .withPackageName(packageName)
                .build()
                .writeToDirectory(outputDirectory)

        private fun typeName(name: String): String = capitalizeWords(name)

        private fun memberName(name: String): String {
            val result = uncapitalize(capitalizeWords(name))
            return if (KEYWORDS.contains(result)) "`$result`" else result
        }

        private fun localName(name: String): String {
            val result = uncapitalize(capitalizeWords(name))
            return if (KEYWORDS.contains(result)) "_$result" else result
        }

        private fun interfaceTypeNames(
            declarations: List<InterfaceDeclaration>
        ): Map<InterfaceDeclaration, String> {
            val simpleCounts = LinkedHashMap<String, Int>()
            for (declaration in declarations) {
                val simpleName = typeName(declaration.name())
                simpleCounts[simpleName] = simpleCounts.getOrDefault(simpleName, 0) + 1
            }

            val result = LinkedHashMap<InterfaceDeclaration, String>()
            val used = LinkedHashMap<String, Int>()
            for (declaration in declarations) {
                val simpleName = typeName(declaration.name())
                val candidate =
                    if (simpleCounts[simpleName] == 1) {
                        simpleName
                    } else {
                        typeName(WitNames.withoutVersion(declaration.qualifiedName()))
                    }
                val count = used.getOrDefault(candidate, 0)
                used[candidate] = count + 1
                result[declaration] = if (count == 0) candidate else candidate + (count + 1)
            }
            return result
        }

        private fun worldTypeNames(
            declarations: List<WorldDeclaration>
        ): Map<WorldDeclaration, String> {
            val simpleCounts = LinkedHashMap<String, Int>()
            for (declaration in declarations) {
                val simpleName = typeName(declaration.name())
                simpleCounts[simpleName] = simpleCounts.getOrDefault(simpleName, 0) + 1
            }

            val result = LinkedHashMap<WorldDeclaration, String>()
            val used = LinkedHashMap<String, Int>()
            for (declaration in declarations) {
                val simpleName = typeName(declaration.name())
                val candidate =
                    if (simpleCounts[simpleName] == 1) {
                        simpleName
                    } else {
                        typeName(WitNames.withoutVersion(declaration.qualifiedName()))
                    }
                val count = used.getOrDefault(candidate, 0)
                used[candidate] = count + 1
                result[declaration] = if (count == 0) candidate else candidate + (count + 1)
            }
            return result
        }

        private fun enumName(name: String): String {
            val result =
                name
                    .replace('-', '_')
                    .replace('.', '_')
                    .replace(':', '_')
                    .replace('/', '_')
                    .uppercase(Locale.ROOT)
            if (result.isEmpty() || !Character.isJavaIdentifierStart(result[0])) {
                return "_$result"
            }
            return result
        }

        private fun capitalizeWords(name: String): String {
            val out = StringBuilder()
            var upper = true
            for (ch in name) {
                if (Character.isLetterOrDigit(ch)) {
                    out.append(if (upper) Character.toUpperCase(ch) else ch)
                    upper = false
                } else {
                    upper = true
                }
            }
            if (out.isEmpty() || !Character.isJavaIdentifierStart(out[0])) {
                out.insert(0, '_')
            }
            return out.toString()
        }

        private fun uncapitalize(value: String): String {
            if (value.isEmpty()) {
                return value
            }
            return Character.toLowerCase(value[0]) + value.substring(1)
        }
    }

    private fun runtimeType(name: String): String =
        if (
            runtimePackageName == null ||
                runtimePackageName.isBlank() ||
                runtimePackageName == packageName
        ) {
            name
        } else {
            runtimePackageName + "." + name
        }

    private fun kotlinString(value: String): String =
        "\"" +
            value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("${'$'}", "\\${'$'}")
                .replace("\n", "\\n")
                .replace("\r", "\\r") +
            "\""

    private fun packageVersion(packageName: String): String {
        val at = packageName.indexOf('@')
        if (at < 0 || at + 1 >= packageName.length) {
            return ""
        }
        return packageName.substring(at + 1)
    }

    private fun packageMajorVersion(version: String): Int {
        if (version.isBlank() || !version[0].isDigit()) {
            return -1
        }
        var index = 0
        while (index < version.length && version[index].isDigit()) {
            index++
        }
        return version.substring(0, index).toInt()
    }
}

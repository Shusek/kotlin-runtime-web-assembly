package uk.shusek.krwa.wasm

object Version {
    @JvmStatic fun version(): String = "0.3.0-rc.13"
}
